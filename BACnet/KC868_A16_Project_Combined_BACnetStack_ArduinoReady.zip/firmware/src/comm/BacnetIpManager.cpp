#include "BacnetIpManager.h"
#include "../FunctionPrototypes.h"
#include "../Globals.h"

// --------------------------------------------------------------------------------------
// bacnet-stack includes (upstream bacnet-stack)
// NOTE: bacnet-stack uses C files, so we wrap in extern "C" for C++.
// --------------------------------------------------------------------------------------
extern "C" {

#include "bacnet/bacdef.h"
#include "bacnet/bacstr.h"
#include "bacnet/bactext.h"
#include "bacnet/iam.h"
#include "bacnet/npdu.h"
#include "bacnet/apdu.h"

#include "bacnet/basic/object/device.h"
#include "bacnet/basic/object/bi.h"
#include "bacnet/basic/object/bo.h"
#include "bacnet/basic/object/ai.h"
#include "bacnet/basic/object/av.h"

#include "bacnet/basic/service/h_rp.h"
#include "bacnet/basic/service/h_wp.h"
#include "bacnet/basic/service/h_rpm.h"
#include "bacnet/basic/service/h_whois.h"
#include "bacnet/basic/service/h_iam.h"
#include "bacnet/basic/service/h_noserv.h"

#include "bacnet/basic/services.h"
#include "bacnet/basic/tsm/tsm.h"
#include "bacnet/basic/sys/mstimer.h"

#include "bacnet/datalink/datalink.h"
#include "bacnet/datalink/bip.h"

} // extern "C"

namespace BacnetIpManager {

    // ------------------------------
    // Internal state/timers
    // ------------------------------
    static bool g_running = false;

    static uint32_t g_lastSyncMs = 0;
    static uint32_t g_lastAnnounceMs = 0;
    static uint32_t g_lastTsmMs = 0;

    static constexpr uint32_t SYNC_PERIOD_MS = 200;     // publish values
    static constexpr uint32_t ANNOUNCE_PERIOD_MS = 30000; // periodic I-Am

    static constexpr uint16_t BACNET_VENDOR_ID = 999;   // change if you have an official vendor ID

    // NOTE:
    // The bacnet-stack demo/server uses fixed buffers. We keep them here so
    // this module is standalone.
    static uint8_t Rx_Buf[MAX_MPDU] = {0};
    static uint8_t Tx_Buf[MAX_MPDU] = {0};

    static void configureHandlers()
    {
        // Confirmed services
        apdu_set_confirmed_handler(SERVICE_CONFIRMED_READ_PROPERTY, handler_read_property);
        apdu_set_confirmed_handler(SERVICE_CONFIRMED_WRITE_PROPERTY, handler_write_property);
        apdu_set_confirmed_handler(SERVICE_CONFIRMED_READ_PROP_MULTIPLE, handler_read_property_multiple);

        // Unconfirmed services
        apdu_set_unconfirmed_handler(SERVICE_UNCONFIRMED_WHO_IS, handler_who_is);
        apdu_set_unconfirmed_handler(SERVICE_UNCONFIRMED_I_AM, handler_i_am_add);

        // Misc
        apdu_set_unrecognized_service_handler_handler(handler_unrecognized_service);
    }

    static void initObjects()
    {
        // Device object
        Device_Set_Object_Instance_Number(bacnetDeviceId);
        Device_Set_Vendor_Identifier(BACNET_VENDOR_ID);

        // Optional: add a friendly device name
        // (Device object-name is usually writeable by default in demo code if enabled)
        BACNET_CHARACTER_STRING csName;
        characterstring_init_ansi(&csName, boardName.c_str());
        Device_Set_Object_Name(&csName);

        // Initialize demo objects (if present in your bacnet-stack build)
        Binary_Input_Init();
        Binary_Output_Init();
        Analog_Input_Init();
        Analog_Value_Init();

        // Create AV objects for sensors (instances 1..6) if the demo requires creation
        // (Some stacks create statically; create is safe if already exists.)
        // If Analog_Value_Create is not available in your bacnet-stack version, you can remove these.
        #ifdef Analog_Value_Create
        for (uint32_t i = 1; i <= 6; i++) {
            Analog_Value_Create(i);
        }
        #endif

        // Assign units (optional, improves client display)
        //  - AI1..AI4 are volts
        //  - AV1..AV6 are degrees C and %RH
        for (uint32_t i = 1; i <= 4; i++) {
            #ifdef Analog_Input_Units_Set
            Analog_Input_Units_Set(i, UNITS_VOLTS);
            #endif
        }
        #ifdef Analog_Value_Units_Set
        Analog_Value_Units_Set(1, UNITS_DEGREES_CELSIUS); // DHT1 temp
        Analog_Value_Units_Set(2, UNITS_PERCENT_RELATIVE_HUMIDITY); // DHT1 hum
        Analog_Value_Units_Set(3, UNITS_DEGREES_CELSIUS); // DHT2 temp
        Analog_Value_Units_Set(4, UNITS_PERCENT_RELATIVE_HUMIDITY); // DHT2 hum
        Analog_Value_Units_Set(5, UNITS_DEGREES_CELSIUS); // DS18B20 temp
        Analog_Value_Units_Set(6, UNITS_NO_UNITS); // reserved / future
        #endif

        // Publish initial values
        syncFromFirmware();
    }

    void init()
    {
        if (g_running) return;

        if (!bacnetIpEnabled) {
            Serial.println("[BACnet] Disabled by config (bacnetIpEnabled=false)");
            return;
        }

        // BACnet/IP UDP port
        bip_set_port(bacnetUdpPort);

        // BACnet datalink init - uses underlying lwIP sockets on ESP32
        if (!datalink_init(nullptr)) {
            Serial.println("[BACnet] datalink_init() failed");
            g_running = false;
            return;
        }

        // Init stack objects and APDU service handlers
        configureHandlers();
        initObjects();

        // Send I-Am on startup
        announce();

        g_running = true;
        g_lastSyncMs = millis();
        g_lastAnnounceMs = millis();
        g_lastTsmMs = millis();

        Serial.printf("[BACnet] BACnet/IP started (DeviceID=%lu, UDP=%u)\n",
                      (unsigned long)bacnetDeviceId,
                      (unsigned)bacnetUdpPort);
    }

    void stop()
    {
        if (!g_running) return;

        // bacnet-stack datalink cleanup varies by port;
        // for most ports, simply stopping receive loop is enough.
        // If your build provides datalink_cleanup(), call it here.
        #ifdef datalink_cleanup
        datalink_cleanup();
        #endif

        g_running = false;
        Serial.println("[BACnet] stopped");
    }

    bool isRunning()
    {
        return g_running;
    }

    void announce()
    {
        if (!bacnetIpEnabled) return;

        // Send I-Am broadcast
        Send_I_Am(Tx_Buf);
        g_lastAnnounceMs = millis();
        Serial.println("[BACnet] I-Am broadcast sent");
    }

    // Map firmware IO into BACnet object PVs
    void syncFromFirmware()
    {
        // Digital Inputs -> BI 1..16
        for (uint32_t i = 1; i <= 16; i++) {
            bool st = inputStates[i - 1];
            // BACnet Binary PV uses enumerated ACTIVE/INACTIVE
            #ifdef Binary_Input_Present_Value_Set
            Binary_Input_Present_Value_Set(i, st ? BINARY_ACTIVE : BINARY_INACTIVE, 16);
            #endif
        }

        // MOSFET Outputs -> BO 1..16
        for (uint32_t i = 1; i <= 16; i++) {
            bool st = outputStates[i - 1];
            #ifdef Binary_Output_Present_Value_Set
            Binary_Output_Present_Value_Set(i, st ? BINARY_ACTIVE : BINARY_INACTIVE, 16);
            #endif
        }

        // Analog Inputs -> AI 1..4 (volts)
        for (uint32_t i = 1; i <= 4; i++) {
            float v = analogValues[i - 1]; // expects already scaled 0..5V
            #ifdef Analog_Input_Present_Value_Set
            Analog_Input_Present_Value_Set(i, v, 16);
            #endif
        }

        // Sensors -> AV objects
        #ifdef Analog_Value_Present_Value_Set
        // DHT1
        Analog_Value_Present_Value_Set(1, sensorValues[0], 16);
        Analog_Value_Present_Value_Set(2, sensorValues[1], 16);
        // DHT2
        Analog_Value_Present_Value_Set(3, sensorValues[2], 16);
        Analog_Value_Present_Value_Set(4, sensorValues[3], 16);
        // DS18B20
        Analog_Value_Present_Value_Set(5, sensorValues[4], 16);
        #endif
    }

    // Apply BO writes from BACnet to hardware outputStates[]
    static void applyOutputsFromBacnet()
    {
        bool changed = false;

        for (uint32_t i = 1; i <= 16; i++) {
            #ifdef Binary_Output_Present_Value
            BACNET_BINARY_PV pv = Binary_Output_Present_Value(i);
            bool newState = (pv == BINARY_ACTIVE);

            if (outputStates[i - 1] != newState) {
                outputStates[i - 1] = newState;
                changed = true;
            }
            #endif
        }

        if (changed) {
            writeOutputs();
            broadcastUpdate(); // notify Web UI, Modbus, etc
        }
    }

    void task()
    {
        if (!g_running) return;

        // Keep BACnet timeouts moving
        uint32_t now = millis();
        uint32_t elapsed = now - g_lastTsmMs;
        if (elapsed >= 5) {
            tsm_timer_milliseconds(elapsed);
            g_lastTsmMs = now;
        }

        // Receive and handle incoming packets
        BACNET_ADDRESS src = {0};
        int pdu_len = datalink_receive(&src, Rx_Buf, MAX_MPDU, 0);
        if (pdu_len > 0) {
            npdu_handler(&src, Rx_Buf, (uint16_t)pdu_len);
        }

        // Periodic sync (publish values)
        if (now - g_lastSyncMs >= SYNC_PERIOD_MS) {
            g_lastSyncMs = now;
            syncFromFirmware();
            applyOutputsFromBacnet();
        }

        // Periodic I-Am broadcast
        if (now - g_lastAnnounceMs >= ANNOUNCE_PERIOD_MS) {
            announce();
        }
    }

} // namespace BacnetIpManager
