Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Threading.Tasks
Imports System.Windows.Forms

Namespace KC868ModbusMaster

    ''' <summary>
    ''' Separate window showing a MODBUS-like table view of BACnet objects.
    ''' Sections are displayed in one DataGridView with a "Section" column.
    ''' BO rows are writable (checkbox).
    ''' </summary>
    Public Class BacnetGridForm
        Inherits Form

        ' BACnet output logic mapping
        ' UI requirement: Checked (Write=True) = Output ON, Unchecked = Output OFF
        ' If physical outputs toggle opposite to the grid Write checkbox, set this to True.
        Private Const BACNET_OUTPUT_ACTIVE_LOW As Boolean = True

        Private ReadOnly _bacnet As BacnetManager
        Private ReadOnly _biBase As UInteger
        Private ReadOnly _boBase As UInteger
        Private ReadOnly _aiBase As UInteger

        Private ReadOnly _timer As New System.Windows.Forms.Timer()
        Private _busy As Boolean = False
        Private _closing As Boolean = False
        Private _suppressWrites As Boolean = False

        Private dgv As DataGridView
        Private dt As DataTable

        Private chkAuto As CheckBox
        Private numInterval As NumericUpDown
        Private btnRead As Button
        Private lblStatus As Label

        Public Sub New(bacnet As BacnetManager, biBase As UInteger, boBase As UInteger, aiBase As UInteger)
            _bacnet = bacnet
            _biBase = biBase
            _boBase = boBase
            _aiBase = aiBase

            Me.Text = "BACnet Grid (BI/BO/AI)"
            Me.StartPosition = FormStartPosition.CenterParent
            Me.Size = New Size(980, 640)

            BuildUi()

            ' Timer will be started after handle is created (Shown event)
            _timer.Interval = 1000
            AddHandler _timer.Tick, AddressOf Timer_Tick
            AddHandler Me.Shown, AddressOf BacnetGridForm_Shown
            AddHandler Me.FormClosing, AddressOf BacnetGridForm_FormClosing
        End Sub

	        ' Start timer only after the form handle is created.
	        Private Async Sub BacnetGridForm_Shown(sender As Object, e As EventArgs)
	            If _closing OrElse Me.IsDisposed Then Return
	            UpdateTimer()
	            ' Initial refresh
	            Await RefreshAllAsync()
	        End Sub

	        Private Sub BacnetGridForm_FormClosing(sender As Object, e As FormClosingEventArgs)
	            _closing = True
	            Try
	                _timer.Stop()
	            Catch
	            End Try
	        End Sub

	        ''' <summary>
	        ''' Safe UI invoke helper to avoid "Invoke/BeginInvoke cannot be called" when handle is not created
	        ''' or after the form has started closing.
	        ''' </summary>
	        Private Sub SafeUi(act As Action)
	            If act Is Nothing Then Return
	            If _closing OrElse Me.IsDisposed Then Return
	            If Not Me.IsHandleCreated Then Return
	            Try
	                If Me.InvokeRequired Then
	                    Me.BeginInvoke(act)
	                Else
	                    act()
	                End If
	            Catch
	                ' Ignore invoke errors during shutdown
	            End Try
	        End Sub

        Private Sub BuildUi()
            Dim root As New TableLayoutPanel() With {.Dock = DockStyle.Fill, .RowCount = 2, .ColumnCount = 1}
            root.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            root.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
            Me.Controls.Add(root)

            Dim bar As New FlowLayoutPanel() With {.Dock = DockStyle.Top, .AutoSize = True, .Padding = New Padding(8)}
            chkAuto = New CheckBox() With {.Text = "Auto Refresh", .AutoSize = True, .Checked = True, .Margin = New Padding(0, 6, 14, 0)}
            bar.Controls.Add(chkAuto)

            bar.Controls.Add(New Label() With {.Text = "Interval (ms):", .AutoSize = True, .Margin = New Padding(0, 8, 6, 0)})
            numInterval = New NumericUpDown() With {.Minimum = 250, .Maximum = 60000, .Value = 1000, .Width = 90}
            bar.Controls.Add(numInterval)

            btnRead = New Button() With {.Text = "Read Now", .Width = 100, .Margin = New Padding(14, 3, 0, 0)}
            bar.Controls.Add(btnRead)

            lblStatus = New Label() With {.Text = "Ready", .AutoSize = True, .ForeColor = Color.DimGray, .Margin = New Padding(14, 8, 0, 0)}
            bar.Controls.Add(lblStatus)

            root.Controls.Add(bar, 0, 0)

            dt = New DataTable()
            dt.Columns.Add("Section", GetType(String))
            dt.Columns.Add("Object", GetType(String))
            dt.Columns.Add("Instance", GetType(Integer))
            dt.Columns.Add("Value", GetType(String))
            dt.Columns.Add("Write", GetType(Boolean))

            ' Sections
            For i As Integer = 0 To 15
                dt.Rows.Add("Binary Inputs", $"BI{i + 1}", CInt(_biBase) + i, "-", False)
            Next
            For i As Integer = 0 To 15
                dt.Rows.Add("Binary Outputs", $"BO{i + 1}", CInt(_boBase) + i, "-", False)
            Next

            ' Analog Inputs (A1..A4) are AI base + 0..3
Dim aiMainNames As String() = {
    "A1 Voltage (V)", "A2 Voltage (V)", "A3 Voltage (V)", "A4 Voltage (V)"
}
For i As Integer = 0 To aiMainNames.Length - 1
    dt.Rows.Add("Analog Inputs", $"AI{CInt(_aiBase) + i} - {aiMainNames(i)}", CInt(_aiBase) + i, "-", False)
Next

' Sensor analog inputs are exposed as fixed instances AI101..AI105 by the firmware
Dim sensorInst() As Integer = {101, 102, 103, 104, 105}
Dim sensorNames As String() = {"DHT1 Temp (°C)", "DHT1 Humidity (%)", "DHT2 Temp (°C)", "DHT2 Humidity (%)", "DS18B20 Temp (°C)"}
For i As Integer = 0 To sensorInst.Length - 1
    dt.Rows.Add("Analog Inputs", $"AI{sensorInst(i)} - {sensorNames(i)}", sensorInst(i), "-", False)
Next

            dgv = New DataGridView() With {
                .Dock = DockStyle.Fill,
                .AutoGenerateColumns = False,
                .AllowUserToAddRows = False,
                .AllowUserToDeleteRows = False,
                .RowHeadersVisible = False,
                .SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                .MultiSelect = False,
                .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            }

            Dim colSec As New DataGridViewTextBoxColumn() With {.HeaderText = "Section", .DataPropertyName = "Section", .FillWeight = 18, .ReadOnly = True}
            Dim colObj As New DataGridViewTextBoxColumn() With {.HeaderText = "Object", .DataPropertyName = "Object", .FillWeight = 22, .ReadOnly = True}
            Dim colInst As New DataGridViewTextBoxColumn() With {.HeaderText = "Instance", .DataPropertyName = "Instance", .FillWeight = 12, .ReadOnly = True}
            Dim colVal As New DataGridViewTextBoxColumn() With {.HeaderText = "Value", .DataPropertyName = "Value", .FillWeight = 28, .ReadOnly = True}
            Dim colWrite As New DataGridViewCheckBoxColumn() With {.HeaderText = "Write", .DataPropertyName = "Write", .FillWeight = 10}

            dgv.Columns.AddRange(New DataGridViewColumn() {colSec, colObj, colInst, colVal, colWrite})
            dgv.DataSource = dt

            ' Nice row separators when section changes
            AddHandler dgv.RowPrePaint, AddressOf Dgv_RowPrePaint
            AddHandler dgv.CellValueChanged, AddressOf Dgv_CellValueChanged
            AddHandler dgv.CurrentCellDirtyStateChanged, Sub()
                                                             If dgv.IsCurrentCellDirty Then
                                                                 dgv.CommitEdit(DataGridViewDataErrorContexts.Commit)
                                                             End If
                                                         End Sub

            root.Controls.Add(dgv, 0, 1)

            AddHandler btnRead.Click, Async Sub(sender As Object, e As EventArgs)
                                          Await RefreshAllAsync()
                                      End Sub
            AddHandler chkAuto.CheckedChanged, Sub() UpdateTimer()
            AddHandler numInterval.ValueChanged, Sub() _timer.Interval = CInt(numInterval.Value)

            UpdateTimer()
        End Sub

        Private Sub UpdateTimer()
            _timer.Interval = CInt(numInterval.Value)
	            If _closing OrElse Me.IsDisposed OrElse Not Me.IsHandleCreated Then
	                _timer.Stop()
	                Return
	            End If
	            If chkAuto.Checked Then
                _timer.Start()
            Else
                _timer.Stop()
            End If
        End Sub

        Private Async Sub Timer_Tick(sender As Object, e As EventArgs)
            If Not chkAuto.Checked Then Return
            Await RefreshAllAsync()
        End Sub


        Private Async Function RefreshAllAsync() As Task
            If _busy Then Return
            If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then
                lblStatus.Text = "Not connected"
                lblStatus.ForeColor = Color.DarkRed
                Return
            End If

            _busy = True
            lblStatus.Text = "Reading..."
            lblStatus.ForeColor = Color.DimGray

            Try
                Await Task.Run(Sub()
                                   Dim di(15) As Boolean
                                   Dim bo(15) As Boolean
                                   Dim ai(8) As Double

                                   ' BI
                                   For i As Integer = 0 To 15
                                       Dim v As Object = Nothing
                                       Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_INPUT, _biBase + CUInt(i), v)
                                       di(i) = If(got, BacnetManager.ToBool(v), False)
                                   Next

                                   ' BO
                                   For i As Integer = 0 To 15
                                       Dim v As Object = Nothing
                                       Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_OUTPUT, _boBase + CUInt(i), v)
                                       bo(i) = If(got, BacnetManager.ToBool(v), False)
                                   Next

                                   ' AI main: A1..A4 (base instances)
For i As Integer = 0 To 3
    Dim v As Object = Nothing
    Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_ANALOG_INPUT, _aiBase + CUInt(i), v)
    If got Then
        ai(i) = Convert.ToDouble(v, Globalization.CultureInfo.InvariantCulture)
    Else
        ai(i) = Double.NaN
    End If
Next

' Sensor AIs: fixed instances 101..105
Dim sensorInst() As UInteger = {101UI, 102UI, 103UI, 104UI, 105UI}
For s As Integer = 0 To sensorInst.Length - 1
    Dim v As Object = Nothing
    Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_ANALOG_INPUT, sensorInst(s), v)
    If got Then
        ai(4 + s) = Convert.ToDouble(v, Globalization.CultureInfo.InvariantCulture)
    Else
        ai(4 + s) = Double.NaN
    End If
Next

                                   SafeUi(Sub() ' Update BI rows
                                                            For i As Integer = 0 To 15
                                                                dt.Rows(i)("Value") = If(di(i), "ON", "OFF")
                                                            Next

                                                            ' Update BO rows (and keep write checkbox synced)
                                                            _suppressWrites = True
                                                            For i As Integer = 0 To 15
                                                                Dim rowIndex As Integer = 16 + i
                                                                ' UI: Write checked = Output ON
                                                                Dim uiState As Boolean = If(BACNET_OUTPUT_ACTIVE_LOW, Not bo(i), bo(i))
                                                                dt.Rows(rowIndex)("Value") = If(uiState, "ON", "OFF")
                                                                dt.Rows(rowIndex)("Write") = uiState
                                                            Next
                                                            _suppressWrites = False

                                                            ' Update AI rows
                                                            Dim baseAiRow As Integer = 32
                                                            For i As Integer = 0 To 8
                                                                dt.Rows(baseAiRow + i)("Value") = If(Double.IsNaN(ai(i)), "-", ai(i).ToString("0.###", Globalization.CultureInfo.InvariantCulture))
                                                            Next

                                                            lblStatus.Text = "OK"
                                                            lblStatus.ForeColor = Color.DarkGreen
                                                        End Sub)
                               End Sub)
            Catch ex As Exception
                lblStatus.Text = "Read error: " & ex.Message
                lblStatus.ForeColor = Color.DarkRed
            Finally
                _busy = False
            End Try
        End Function

        Private Sub Dgv_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs)
            If _suppressWrites Then Return
            If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Return

            ' Only BO section is writable via checkbox
            Dim section As String = Convert.ToString(dt.Rows(e.RowIndex)("Section"))
            If Not String.Equals(section, "Binary Outputs", StringComparison.OrdinalIgnoreCase) Then Return

            If dgv.Columns(e.ColumnIndex).HeaderText <> "Write" Then Return

            ' UI: Write checked = Output ON
            Dim desiredUi As Boolean = Convert.ToBoolean(dt.Rows(e.RowIndex)("Write"))
            Dim desiredDevice As Boolean = If(BACNET_OUTPUT_ACTIVE_LOW, Not desiredUi, desiredUi)
            Dim inst As UInteger = CUInt(Convert.ToInt32(dt.Rows(e.RowIndex)("Instance")))

	            Task.Run(Sub()
	                         Dim ok As Boolean = _bacnet.TryWriteBinaryOutput(inst, desiredDevice)
	                         SafeUi(Sub()
	                                    If ok Then
	                                        dt.Rows(e.RowIndex)("Value") = If(desiredUi, "ON", "OFF")
	                                        lblStatus.Text = "Write OK"
	                                        lblStatus.ForeColor = Color.DarkGreen
	                                    Else
	                                        lblStatus.Text = "Write FAIL"
	                                        lblStatus.ForeColor = Color.DarkRed
	                                    End If
	                                End Sub)
	                     End Sub)
        End Sub

        Private Sub Dgv_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs)
            ' Draw a separator line when section changes
            If e.RowIndex <= 0 Then Return
            Dim secNow As String = Convert.ToString(dt.Rows(e.RowIndex)("Section"))
            Dim secPrev As String = Convert.ToString(dt.Rows(e.RowIndex - 1)("Section"))
            If Not String.Equals(secNow, secPrev, StringComparison.OrdinalIgnoreCase) Then
                Using p As New Pen(Color.Silver, 1)
                    e.Graphics.DrawLine(p, e.RowBounds.Left, e.RowBounds.Top, e.RowBounds.Right, e.RowBounds.Top)
                End Using
            End If
        End Sub

    End Class

End Namespace