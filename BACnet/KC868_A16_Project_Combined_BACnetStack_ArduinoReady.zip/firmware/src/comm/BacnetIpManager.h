#pragma once
/*
  BacnetIpManager.h
  BACnet/IP driver wrapper for KC868-A16 ESP32 (LAN8720A)

  This module is designed to be added on top of the existing firmware WITHOUT
  changing existing features. It exposes the current device state (I/O, sensors,
  RTC, network info) as BACnet objects over BACnet/IP UDP (default 47808).

  Requirements:
  - Add the open-source "bacnet-stack" library to your Arduino project/toolchain.
    Official repository: https://github.com/bacnet-stack/bacnet-stack 
  - Ensure bacnet-stack object demo files are enabled for:
      Device, Binary Input, Binary Output, Analog Input, Analog Value.
    The driver uses the common demo API functions such as:
      Binary_Output_Present_Value_Set(), Analog_Input_Present_Value_Set()

  Object Model exposed (instances are 1-based):
  - Device:        DEVICE_INSTANCE = bacnetDeviceId
  - BI 1..16:      Digital Inputs 1..16
  - BO 1..16:      MOSFET Outputs 1..16  (Writeable Present_Value)
  - AI 1..4:       Analog Inputs A1..A4 in volts
  - AV 1..6:       Sensor values (Temp/Humidity) + DS18B20
    (AV objects are used to represent non-physical "values in memory".)
*/

#include <Arduino.h>

namespace BacnetIpManager {
    // Call from appSetup() after network (ETH/WiFi) is up
    void init();

    // Call from appLoop() frequently (every iteration)
    void task();

    // Stop BACnet/IP (closes socket)
    void stop();

    // Status
    bool isRunning();

    // Force a "I-Am" broadcast
    void announce();

    // Push current firmware state into BACnet objects
    void syncFromFirmware();
}
