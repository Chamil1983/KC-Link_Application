#pragma once
/**
 * ModbusManager.h
 * Modbus RTU Slave for KC868-A16 over RS485 (UART1).
 *
 * ESP32 = Modbus RTU Slave/Server
 * VB.NET = Modbus RTU Master (NModbus4)
 */

#include <Arduino.h>

void initModbus();
void modbusTask();
bool modbusIsEnabled();
