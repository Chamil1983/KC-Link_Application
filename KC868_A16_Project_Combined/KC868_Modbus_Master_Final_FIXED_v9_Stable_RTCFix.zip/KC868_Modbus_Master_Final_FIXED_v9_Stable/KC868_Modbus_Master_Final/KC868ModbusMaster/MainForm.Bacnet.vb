Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Threading.Tasks
Imports System.Windows.Forms


Namespace KC868ModbusMaster

    Partial Public Class MainForm

        ' BACnet output logic mapping
        ' UI requirement: Checked = Output ON, Unchecked = Output OFF
        ' If your physical outputs toggle opposite to the BACnet UI, set this to True.
        ' (This does NOT affect Modbus code.)
        Private Const BACNET_OUTPUT_ACTIVE_LOW As Boolean = True

        Friend WithEvents tabBacnet As TabPage

        Private _bacnet As BacnetManager
        Private _bacnetPollTimer As Timer
        Private _bacnetIsPolling As Boolean = False
        Private _bacnetSuppressWrites As Boolean = False
        Private _bacnetConsecutiveFails As Integer = 0

        Private _biBase As UInteger = 1UI
        Private _boBase As UInteger = 1UI
        Private _aiBase As UInteger = 1UI
        Private _baseKnown As Boolean = False

        ' ---------- BACnet UI ----------
        Private grpBacnetConn As GroupBox
        Private txtBacnetIp As TextBox
        Private numBacnetPort As NumericUpDown
        Private numBacnetDevId As NumericUpDown
        Private numBacnetRefreshMs As NumericUpDown
        Private chkBacnetAutoRefresh As CheckBox
        Private btnBacnetConnect As Button
        Private btnBacnetDisconnect As Button
        Private btnBacnetReadNow As Button
        Private btnBacnetDiscover As Button
        Private cboBacnetDevices As ComboBox

        ' Optional BBMD / cross-subnet support
        Private chkBacnetUseBbmd As CheckBox
        Private txtBacnetBbmdIp As TextBox
        Private numBacnetBbmdPort As NumericUpDown
        Private numBacnetBbmdTtl As NumericUpDown
        Private btnBacnetBbmdRegister As Button

        Private btnBacnetOpenGrid As Button
        Private lblBacnetStatus As Label

        Private dgvBacnetBoard As DataGridView
        Private dgvBacnetNet As DataGridView
        Private dgvBacnetSerial As DataGridView
        Private dgvBacnetAnalog As DataGridView

        Private _dtBoard As DataTable
        Private _dtNet As DataTable
        Private _dtSerial As DataTable
        Private _dtAnalog As DataTable

        Private bacnetChkDo(15) As CheckBox
        Private bacnetLedDi(15) As Panel
        Private bacnetLedText(15) As Label
        Private bacnetLedCaption(15) As Label

        Private _lastStaticInfoRead As DateTime = DateTime.MinValue

        Private Sub BuildBacnetUi()
            If tabBacnet Is Nothing Then Return

            tabBacnet.Controls.Clear()

            Dim root As New TableLayoutPanel() With {.Dock = DockStyle.Fill, .ColumnCount = 1, .RowCount = 2, .Padding = New Padding(8)}
            root.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            root.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
            tabBacnet.Controls.Add(root)

            ' Connection group
            grpBacnetConn = New GroupBox() With {.Text = "BACnet Connection (System.IO.BACnet)", .Dock = DockStyle.Top, .AutoSize = True}
            root.Controls.Add(grpBacnetConn, 0, 0)

            Dim conn As New TableLayoutPanel() With {.Dock = DockStyle.Fill, .ColumnCount = 10, .AutoSize = True}
            For i As Integer = 0 To 9
                conn.ColumnStyles.Add(New ColumnStyle(SizeType.AutoSize))
            Next

            conn.Controls.Add(New Label() With {.Text = "Device IP:", .AutoSize = True, .Margin = New Padding(8, 10, 6, 0)}, 0, 0)
            txtBacnetIp = New TextBox() With {.Width = 140, .Text = "192.168.1.200"}
            conn.Controls.Add(txtBacnetIp, 1, 0)

            conn.Controls.Add(New Label() With {.Text = "Port:", .AutoSize = True, .Margin = New Padding(14, 10, 6, 0)}, 2, 0)
            numBacnetPort = New NumericUpDown() With {.Minimum = 1, .Maximum = 65535, .Value = 47808, .Width = 80}
            conn.Controls.Add(numBacnetPort, 3, 0)

            conn.Controls.Add(New Label() With {.Text = "Device ID:", .AutoSize = True, .Margin = New Padding(14, 10, 6, 0)}, 4, 0)
            numBacnetDevId = New NumericUpDown() With {.Minimum = 0, .Maximum = 4194303, .Value = 88160, .Width = 90}
            conn.Controls.Add(numBacnetDevId, 5, 0)

            btnBacnetConnect = New Button() With {.Text = "Connect", .Width = 92, .Margin = New Padding(14, 6, 0, 6)}
            btnBacnetDisconnect = New Button() With {.Text = "Disconnect", .Width = 92, .Margin = New Padding(8, 6, 0, 6), .Enabled = False}
            btnBacnetReadNow = New Button() With {.Text = "Read Now", .Width = 92, .Margin = New Padding(8, 6, 0, 6), .Enabled = False}
            conn.Controls.Add(btnBacnetConnect, 6, 0)
            conn.Controls.Add(btnBacnetDisconnect, 7, 0)
            conn.Controls.Add(btnBacnetReadNow, 8, 0)

            lblBacnetStatus = New Label() With {.Text = "Disconnected", .AutoSize = True, .ForeColor = Color.DarkRed, .Margin = New Padding(14, 10, 0, 0)}
            conn.Controls.Add(lblBacnetStatus, 9, 0)

            ' Second row: Auto refresh
            conn.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            conn.Controls.Add(New Label() With {.Text = "Auto Refresh:", .AutoSize = True, .Margin = New Padding(8, 10, 6, 0)}, 0, 1)
            chkBacnetAutoRefresh = New CheckBox() With {.Checked = True, .AutoSize = True, .Margin = New Padding(0, 8, 0, 0)}
            conn.Controls.Add(chkBacnetAutoRefresh, 1, 1)

            conn.Controls.Add(New Label() With {.Text = "Interval (ms):", .AutoSize = True, .Margin = New Padding(14, 10, 6, 0)}, 2, 1)
            numBacnetRefreshMs = New NumericUpDown() With {.Minimum = 250, .Maximum = 60000, .Value = 1000, .Width = 90}
            conn.Controls.Add(numBacnetRefreshMs, 3, 1)

            ' Third row: Discovery picker + Grid
            conn.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            conn.Controls.Add(New Label() With {.Text = "Discovery:", .AutoSize = True, .Margin = New Padding(8, 10, 6, 0)}, 0, 2)
            cboBacnetDevices = New ComboBox() With {.DropDownStyle = ComboBoxStyle.DropDownList, .Width = 220}
            conn.Controls.Add(cboBacnetDevices, 1, 2)
            btnBacnetDiscover = New Button() With {.Text = "Discover", .Width = 92, .Margin = New Padding(14, 6, 0, 6)}
            conn.Controls.Add(btnBacnetDiscover, 2, 2)

            btnBacnetOpenGrid = New Button() With {.Text = "Open Grid", .Width = 92, .Margin = New Padding(8, 6, 0, 6)}
            conn.Controls.Add(btnBacnetOpenGrid, 3, 2)

            ' Fourth row: BBMD (optional cross-subnet)
            conn.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            chkBacnetUseBbmd = New CheckBox() With {.Text = "Use BBMD", .AutoSize = True, .Margin = New Padding(8, 8, 0, 0)}
            conn.Controls.Add(chkBacnetUseBbmd, 0, 3)

            txtBacnetBbmdIp = New TextBox() With {.Width = 140, .Text = ""}
            conn.Controls.Add(txtBacnetBbmdIp, 1, 3)

            numBacnetBbmdPort = New NumericUpDown() With {.Minimum = 1, .Maximum = 65535, .Value = 47808, .Width = 80}
            conn.Controls.Add(numBacnetBbmdPort, 2, 3)

            numBacnetBbmdTtl = New NumericUpDown() With {.Minimum = 10, .Maximum = 3600, .Value = 120, .Width = 90}
            conn.Controls.Add(numBacnetBbmdTtl, 3, 3)

            btnBacnetBbmdRegister = New Button() With {.Text = "Register", .Width = 92, .Margin = New Padding(8, 6, 0, 6)}
            conn.Controls.Add(btnBacnetBbmdRegister, 4, 3)

            grpBacnetConn.Controls.Add(conn)

            ' Content layout
            Dim content As New TableLayoutPanel() With {.Dock = DockStyle.Fill, .ColumnCount = 2, .RowCount = 3, .Margin = New Padding(0)}
            content.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50.0F))
            content.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50.0F))
            content.RowStyles.Add(New RowStyle(SizeType.Percent, 32.0F))
            content.RowStyles.Add(New RowStyle(SizeType.Percent, 28.0F))
            content.RowStyles.Add(New RowStyle(SizeType.Percent, 40.0F))
            root.Controls.Add(content, 0, 1)

            ' Section 1: Board Info
            Dim grpBoard As New GroupBox() With {.Text = "Section 1 - Board Information", .Dock = DockStyle.Fill, .Padding = New Padding(8)}
            dgvBacnetBoard = CreateKVGrid(_dtBoard, New String() {
                "Device Name",
                "Device Description",
                "Device Location",
                "Board Name",
                "Serial Number",
                "Board MAC Address",
                "Manufacturer",
                "Firmware Version",
                "Hardware Version",
                "Year of Development"
            })
            grpBoard.Controls.Add(dgvBacnetBoard)
            content.Controls.Add(grpBoard, 0, 0)

            ' Section 2: Network Info
            Dim grpNet As New GroupBox() With {.Text = "Section 2 - Network Information (Ethernet)", .Dock = DockStyle.Fill, .Padding = New Padding(8)}
            dgvBacnetNet = CreateKVGrid(_dtNet, New String() {
                "BACnet IP",
                "BACnet Port",
                "BACnet Device ID",
                "Subnet Mask",
                "Gateway",
                "DNS",
                "AP SSID",
                "AP Password",
                "AP IP Address"
            })
            grpNet.Controls.Add(dgvBacnetNet)
            content.Controls.Add(grpNet, 1, 0)

            ' Section 3: Serial + MODBUS Info (read-only)
            Dim grpSerial As New GroupBox() With {.Text = "Section 3 - Communication (Serial) + MODBUS Settings", .Dock = DockStyle.Fill, .Padding = New Padding(8)}
            dgvBacnetSerial = CreateKVGrid(_dtSerial, New String() {
                "COM Port",
                "Baud Rate",
                "Data Bits",
                "Parity",
                "Stop Bits"
            })
            grpSerial.Controls.Add(dgvBacnetSerial)
            content.Controls.Add(grpSerial, 0, 1)

            ' Section 4: Analog + Sensors table
            Dim grpAnalog As New GroupBox() With {.Text = "Analog Inputs + Sensors", .Dock = DockStyle.Fill, .Padding = New Padding(8)}
            dgvBacnetAnalog = CreateKVGrid(_dtAnalog, New String() {
                "A1 (GPIO36) Voltage (V)",
                "A2 (GPIO34) Voltage (V)",
                "A3 (GPIO35) Voltage (V)",
                "A4 (GPIO39) Voltage (V)",
                "DHT1 Temp (°C)",
                "DHT1 Humidity (%)",
                "DHT2 Temp (°C)",
                "DHT2 Humidity (%)",
                "DS18B20 Temp (°C)"
            })
            grpAnalog.Controls.Add(dgvBacnetAnalog)
            content.Controls.Add(grpAnalog, 1, 1)

            ' Hardware control section
            Dim grpHw As New GroupBox() With {.Text = "Section 4 - Hardware (BI/BO/AI) Live Monitor + Control", .Dock = DockStyle.Fill, .Padding = New Padding(8)}
            content.Controls.Add(grpHw, 0, 2)
            content.SetColumnSpan(grpHw, 2)

            Dim hwLayout As New TableLayoutPanel() With {.Dock = DockStyle.Fill, .ColumnCount = 2, .RowCount = 1}
            hwLayout.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50.0F))
            hwLayout.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50.0F))
            grpHw.Controls.Add(hwLayout)

            ' Inputs (BI)
            Dim grpInputs As New GroupBox() With {.Text = "Digital Inputs (BI 1..16)", .Dock = DockStyle.Fill, .Padding = New Padding(8)}
            Dim inGrid As New TableLayoutPanel() With {
                .Dock = DockStyle.Fill,
                .AutoScroll = True,
                .ColumnCount = 4,
                .RowCount = 4,
                .Padding = New Padding(8)
            }
            For c As Integer = 0 To 3
                inGrid.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
            Next
            For r As Integer = 0 To 3
                inGrid.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            Next

            For i As Integer = 0 To 15
                Dim led As Panel = Nothing
                Dim stateLabel As Label = Nothing
                Dim capLabel As Label = Nothing
                Dim item As Control = CreateBacnetDiItem($"DI{i + 1}", led, capLabel, stateLabel)
                bacnetLedDi(i) = led
                bacnetLedCaption(i) = capLabel
                bacnetLedText(i) = stateLabel
                inGrid.Controls.Add(item, i Mod 4, i \ 4)
            Next

            grpInputs.Controls.Add(inGrid)
            hwLayout.Controls.Add(grpInputs, 0, 0)

            ' Outputs (BO)
            Dim grpOutputs As New GroupBox() With {.Text = "MOSFET Outputs (BO 1..16)", .Dock = DockStyle.Fill, .Padding = New Padding(8)}

            ' Arrange DO checkboxes as 2 rows x 8 columns (clean layout)
            Dim outGrid As New TableLayoutPanel() With {
    .Dock = DockStyle.Fill,
    .ColumnCount = 8,
    .RowCount = 2,
    .AutoScroll = True,
    .Padding = New Padding(8)
}
            For c As Integer = 0 To 7
                outGrid.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 12.5F))
            Next
            outGrid.RowStyles.Add(New RowStyle(SizeType.AutoSize))
            outGrid.RowStyles.Add(New RowStyle(SizeType.AutoSize))

            For i As Integer = 0 To 15
                Dim cb As New CheckBox() With {
        .Text = $"DO{i + 1}",
        .AutoSize = True,
        .Margin = New Padding(10, 8, 10, 8),
        .Checked = False
    }
                bacnetChkDo(i) = cb
                outGrid.Controls.Add(cb, i Mod 8, i \ 8)
            Next

            grpOutputs.Controls.Add(outGrid)
            hwLayout.Controls.Add(grpOutputs, 1, 0)

            ' Wire events
            AddHandler btnBacnetConnect.Click, AddressOf BtnBacnetConnect_Click
            AddHandler btnBacnetDisconnect.Click, AddressOf BtnBacnetDisconnect_Click
            AddHandler btnBacnetReadNow.Click, Sub() TriggerBacnetPoll()
            AddHandler btnBacnetDiscover.Click, AddressOf BtnBacnetDiscover_Click
            AddHandler cboBacnetDevices.SelectedIndexChanged, AddressOf CboBacnetDevices_SelectedIndexChanged
            AddHandler btnBacnetBbmdRegister.Click, AddressOf BtnBacnetBbmdRegister_Click
            AddHandler btnBacnetOpenGrid.Click, AddressOf BtnBacnetOpenGrid_Click
            AddHandler tabBacnet.Enter, AddressOf BacnetTab_Enter

            AddHandler chkBacnetAutoRefresh.CheckedChanged, Sub() UpdateBacnetTimerState()
            AddHandler numBacnetRefreshMs.ValueChanged, Sub()
                                                            If _bacnetPollTimer IsNot Nothing Then _bacnetPollTimer.Interval = CInt(numBacnetRefreshMs.Value)
                                                        End Sub

            For i As Integer = 0 To 15
                Dim idx As Integer = i
                AddHandler bacnetChkDo(i).CheckedChanged, Sub(sender, e) BacnetOutputChanged(idx)
            Next

            ' Poll timer (created once)
            If _bacnetPollTimer Is Nothing Then
                _bacnetPollTimer = New Timer() With {.Interval = CInt(numBacnetRefreshMs.Value)}
                AddHandler _bacnetPollTimer.Tick, AddressOf BacnetPollTimer_Tick
            End If

            ' Pre-fill fixed values
            SetKV(_dtBoard, "Manufacturer", "Microcode Engineering Pvt Ltd")
            SetKV(_dtBoard, "Year of Development", DateTime.Now.Year.ToString())
            RefreshSerialSummary()

            SetKV(_dtNet, "BACnet IP", txtBacnetIp.Text)
            SetKV(_dtNet, "BACnet Port", numBacnetPort.Value.ToString())
            SetKV(_dtNet, "BACnet Device ID", numBacnetDevId.Value.ToString())

            ' Ensure outputs start unchecked (no stale UI states) when entering BACnet tab
            ResetBacnetUiState()
        End Sub

        Private Sub BacnetTab_Enter(sender As Object, e As EventArgs)
            ' When user switches to BACnet tab, show a clean default UI before fresh read arrives.
            For i As Integer = 0 To 15
                If bacnetChkDo(i) IsNot Nothing Then bacnetChkDo(i).Checked = False
            Next
            ResetBacnetUiState()
        End Sub

        Private Sub ResetBacnetUiState()
            Try
                _bacnetSuppressWrites = True
                For i As Integer = 0 To 15
                    If bacnetChkDo(i) IsNot Nothing Then bacnetChkDo(i).Checked = False
                Next
            Finally
                _bacnetSuppressWrites = False
            End Try

            ' Reset DI indicators to unknown
            For i As Integer = 0 To 15
                If bacnetLedDi(i) IsNot Nothing Then bacnetLedDi(i).BackColor = Color.DarkRed
                If bacnetLedText(i) IsNot Nothing Then bacnetLedText(i).Text = "-"
            Next
        End Sub


        ' Small DI item with: LED + caption + state label
        Private Function CreateBacnetDiItem(caption As String, ByRef ledPanel As Panel, ByRef captionLabel As Label, ByRef stateLabel As Label) As Control
            Dim host As New Panel() With {.Height = 30, .Margin = New Padding(4)}
            Dim fl As New FlowLayoutPanel() With {.Dock = DockStyle.Fill, .FlowDirection = FlowDirection.LeftToRight, .WrapContents = False, .AutoSize = True}

            ledPanel = New Panel() With {.Width = 14, .Height = 14, .BackColor = Drawing.Color.DarkRed, .Margin = New Padding(0, 6, 8, 0)}
            captionLabel = New Label() With {.Text = caption, .AutoSize = True, .Margin = New Padding(0, 5, 6, 0)}
            stateLabel = New Label() With {.Text = "-", .AutoSize = True, .ForeColor = Drawing.Color.DimGray, .Margin = New Padding(0, 5, 0, 0)}

            fl.Controls.Add(ledPanel)
            fl.Controls.Add(captionLabel)
            fl.Controls.Add(stateLabel)
            host.Controls.Add(fl)
            Return host
        End Function

        Private Function CreateKVGrid(ByRef dt As DataTable, fields As String()) As DataGridView
            dt = New DataTable()
            dt.Columns.Add("Field", GetType(String))
            dt.Columns.Add("Value", GetType(String))

            For Each f As String In fields
                dt.Rows.Add(f, "")
            Next

            Dim grid As New DataGridView() With {
                .Dock = DockStyle.Fill,
                .ReadOnly = True,
                .AllowUserToAddRows = False,
                .AllowUserToDeleteRows = False,
                .RowHeadersVisible = False,
                .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                .SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                .MultiSelect = False,
                .AutoGenerateColumns = False
            }

            ' Explicit columns to avoid "Index out of range" before auto-generated columns exist
            Dim colField As New DataGridViewTextBoxColumn() With {
                .Name = "colField",
                .HeaderText = "Field",
                .DataPropertyName = "Field",
                .FillWeight = 45,
                .ReadOnly = True
            }
            Dim colValue As New DataGridViewTextBoxColumn() With {
                .Name = "colValue",
                .HeaderText = "Value",
                .DataPropertyName = "Value",
                .FillWeight = 55,
                .ReadOnly = True
            }

            grid.Columns.Add(colField)
            grid.Columns.Add(colValue)

            grid.DataSource = dt

            Return grid
        End Function

        Private Sub SetKV(dt As DataTable, key As String, value As String)
            If dt Is Nothing Then Return
            For Each r As DataRow In dt.Rows
                If String.Equals(CStr(r("Field")), key, StringComparison.OrdinalIgnoreCase) Then
                    r("Value") = value
                    Exit Sub
                End If
            Next
        End Sub

        Private Sub RefreshSerialSummary()
            Try
                ' Read current MODBUS settings from the existing MODBUS UI controls (read-only mirror)
                If cboPort IsNot Nothing Then SetKV(_dtSerial, "COM Port", CStr(cboPort.SelectedItem))
                ' In this project the MODBUS settings are ComboBoxes (cboBaud/cboDataBits)
                If cboBaud IsNot Nothing Then SetKV(_dtSerial, "Baud Rate", If(cboBaud.SelectedItem, cboBaud.Text).ToString())
                If cboDataBits IsNot Nothing Then SetKV(_dtSerial, "Data Bits", If(cboDataBits.SelectedItem, cboDataBits.Text).ToString())
                If cboParity IsNot Nothing Then SetKV(_dtSerial, "Parity", CStr(cboParity.SelectedItem))
                If cboStopBits IsNot Nothing Then SetKV(_dtSerial, "Stop Bits", CStr(cboStopBits.SelectedItem))
            Catch
            End Try
        End Sub

        Private Sub BtnBacnetConnect_Click(sender As Object, e As EventArgs)
            Try
                If _bacnet Is Nothing Then _bacnet = New BacnetManager()

                Dim ip As String = txtBacnetIp.Text.Trim()
                Dim port As Integer = CInt(numBacnetPort.Value)
                Dim devId As UInteger = CUInt(numBacnetDevId.Value)

                _bacnet.Connect(ip, port, devId)
                _baseKnown = False
                _bacnetConsecutiveFails = 0

                SetBacnetStatus("Connected (binding...)", True)
                btnBacnetConnect.Enabled = False
                btnBacnetDisconnect.Enabled = True
                btnBacnetReadNow.Enabled = True

                SetKV(_dtNet, "BACnet IP", ip)
                SetKV(_dtNet, "BACnet Port", port.ToString())
                SetKV(_dtNet, "BACnet Device ID", devId.ToString())

                UpdateBacnetTimerState()
                TriggerBacnetPoll(forceStatic:=True)
            Catch ex As Exception
                SetBacnetStatus("Connect failed: " & ex.Message, False)
                btnBacnetConnect.Enabled = True
                btnBacnetDisconnect.Enabled = False
                btnBacnetReadNow.Enabled = False
            End Try
        End Sub

        Private Sub BtnBacnetDisconnect_Click(sender As Object, e As EventArgs)
            Try
                If _bacnetPollTimer IsNot Nothing Then _bacnetPollTimer.Stop()
                If _bacnet IsNot Nothing Then _bacnet.Disconnect()
            Catch
            End Try

            btnBacnetConnect.Enabled = True
            btnBacnetDisconnect.Enabled = False
            btnBacnetReadNow.Enabled = False
            SetBacnetStatus("Disconnected", False)
        End Sub

        Private Sub BtnBacnetDiscover_Click(sender As Object, e As EventArgs)
            Try
                If _bacnet Is Nothing Then _bacnet = New BacnetManager()

                ' Start local UDP even if not "connected" yet
                If Not _bacnet.IsStarted Then _bacnet.Start()

                Dim useBbmd As Boolean = (chkBacnetUseBbmd IsNot Nothing AndAlso chkBacnetUseBbmd.Checked)
                Dim bbmdIp As String = If(txtBacnetBbmdIp IsNot Nothing, txtBacnetBbmdIp.Text.Trim(), "")
                Dim bbmdPort As Integer = If(numBacnetBbmdPort IsNot Nothing, CInt(numBacnetBbmdPort.Value), 47808)

                Dim list As List(Of BacnetDiscoveredDevice) = _bacnet.DiscoverDevices(1500, useBbmd, bbmdIp, bbmdPort)

                cboBacnetDevices.Items.Clear()
                For Each d In list
                    cboBacnetDevices.Items.Add(d)
                Next

                If cboBacnetDevices.Items.Count > 0 Then
                    cboBacnetDevices.SelectedIndex = 0
                    SetBacnetStatus($"Discovered {cboBacnetDevices.Items.Count} device(s)", True)
                Else
                    SetBacnetStatus("No devices found", False)
                End If
            Catch ex As Exception
                SetBacnetStatus("Discover failed: " & ex.Message, False)
            End Try
        End Sub

        Private Sub CboBacnetDevices_SelectedIndexChanged(sender As Object, e As EventArgs)
            Try
                Dim d As BacnetDiscoveredDevice = TryCast(cboBacnetDevices.SelectedItem, BacnetDiscoveredDevice)
                If d Is Nothing Then Return

                txtBacnetIp.Text = d.Address
                numBacnetPort.Value = Math.Min(numBacnetPort.Maximum, Math.Max(numBacnetPort.Minimum, d.Port))
                numBacnetDevId.Value = Math.Min(numBacnetDevId.Maximum, Math.Max(numBacnetDevId.Minimum, d.DeviceInstance))

                SetKV(_dtNet, "BACnet IP", d.Address)
                SetKV(_dtNet, "BACnet Port", d.Port.ToString())
                SetKV(_dtNet, "BACnet Device ID", d.DeviceInstance.ToString())
            Catch
            End Try
        End Sub

        Private Sub BtnBacnetBbmdRegister_Click(sender As Object, e As EventArgs)
            Try
                If _bacnet Is Nothing Then _bacnet = New BacnetManager()
                If Not _bacnet.IsStarted Then _bacnet.Start()

                If chkBacnetUseBbmd Is Nothing OrElse Not chkBacnetUseBbmd.Checked Then
                    SetBacnetStatus("BBMD disabled", True)
                    Return
                End If

                Dim bbmdIp As String = txtBacnetBbmdIp.Text.Trim()
                If String.IsNullOrWhiteSpace(bbmdIp) Then
                    SetBacnetStatus("Enter BBMD IP", False)
                    Return
                End If

                Dim bbmdPort As Integer = CInt(numBacnetBbmdPort.Value)
                Dim ttl As Integer = CInt(numBacnetBbmdTtl.Value)

                Dim ok As Boolean = _bacnet.RegisterForeignDevice(bbmdIp, bbmdPort, ttl)
                SetBacnetStatus(If(ok, "BBMD register OK", "BBMD register FAIL"), ok)
            Catch ex As Exception
                SetBacnetStatus("BBMD error: " & ex.Message, False)
            End Try
        End Sub

        Private Sub BtnBacnetOpenGrid_Click(sender As Object, e As EventArgs)
            Try
                If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then
                    MessageBox.Show("Connect BACnet first.", "BACnet")
                    Return
                End If

                EnsureInstanceBases()

                Dim f As New KC868ModbusMaster.BacnetGridForm(_bacnet, _biBase, _boBase, _aiBase)
                f.Show(Me)
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Open Grid")
            End Try
        End Sub

        Private Sub UpdateBacnetTimerState()
            If _bacnetPollTimer Is Nothing Then Return
            If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then
                _bacnetPollTimer.Stop()
                Return
            End If

            _bacnetPollTimer.Interval = CInt(numBacnetRefreshMs.Value)
            If chkBacnetAutoRefresh.Checked Then
                _bacnetPollTimer.Start()
            Else
                _bacnetPollTimer.Stop()
            End If
        End Sub

        Private Sub BacnetPollTimer_Tick(sender As Object, e As EventArgs)
            TriggerBacnetPoll()
        End Sub

        Private Sub TriggerBacnetPoll(Optional forceStatic As Boolean = False)
            If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then Return
            If _bacnetIsPolling Then Return
            _bacnetIsPolling = True

            RefreshSerialSummary()

            Task.Run(Sub()
                         Dim ok As Boolean = False
                         Dim di(15) As Boolean
                         Dim doo(15) As Boolean
                         Dim ai(8) As Double

                         Try
                             EnsureInstanceBases()
' Phase-1 RPM snapshot polling (reduces UDP load dramatically)
Dim gotSnap As Boolean = False
Try
    gotSnap = _bacnet.TryReadSnapshotRPM(di, doo, ai)
Catch
    gotSnap = False
End Try

ok = ok OrElse gotSnap

' Fallback: per-point polling (kept for compatibility / troubleshooting)
If Not gotSnap Then


                             ' BI 1..16
                             For i As Integer = 0 To 15
                                 Dim v As Object = Nothing
                                 Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_INPUT, _biBase + CUInt(i), v)
                                 di(i) = If(got, BacnetManager.ToBool(v), False)
                                 ok = ok OrElse got
                             Next

                             ' BO 1..16 (read-back)
                             For i As Integer = 0 To 15
                                 Dim v As Object = Nothing
                                 Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_OUTPUT, _boBase + CUInt(i), v)
                                 doo(i) = If(got, BacnetManager.ToBool(v), False)
                                 ok = ok OrElse got
                             Next

                             ' AI: A1..A4 (Voltage), then sensor AIs (DHT/DS18B20)
                             ' Firmware exposes:
                             '  - AI 1..4  : Voltages (A1..A4)
                             '  - AI 101..105 : Sensors (DHT1 Temp/RH, DHT2 Temp/RH, DS18B20 Temp)
                             For i As Integer = 0 To 3
                                 Dim v As Object = Nothing
                                 Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_ANALOG_INPUT, _aiBase + CUInt(i), v)
                                 If got Then
                                     ai(i) = Convert.ToDouble(v, Globalization.CultureInfo.InvariantCulture)
                                     ok = True
                                 Else
                                     ai(i) = Double.NaN
                                 End If
                             Next

                             Dim sensorInst() As UInteger = {101UI, 102UI, 103UI, 104UI, 105UI}
                             For s As Integer = 0 To sensorInst.Length - 1
                                 Dim v As Object = Nothing
                                 Dim got As Boolean = _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_ANALOG_INPUT, sensorInst(s), v)
                                 If got Then
                                     ai(4 + s) = Convert.ToDouble(v, Globalization.CultureInfo.InvariantCulture)
                                     ok = True
                                 Else
                                     ai(4 + s) = Double.NaN
                                 End If
                             Next


End If

                         Catch
                             ok = False
                         End Try

                         Dim needStatic As Boolean = forceStatic OrElse (DateTime.Now - _lastStaticInfoRead).TotalSeconds >= 10

                         Me.BeginInvoke(CType(Sub()
                                                  _bacnetIsPolling = False

                                                  If Not ok Then
                                                      _bacnetConsecutiveFails += 1
                                                      SetBacnetStatus("No response (retry " & _bacnetConsecutiveFails.ToString() & ")", False)
                                                      If _bacnetConsecutiveFails >= 3 Then
                                                          ' Auto reconnect attempt
                                                          btnBacnetConnect.Enabled = True
                                                          btnBacnetDisconnect.Enabled = False
                                                          btnBacnetReadNow.Enabled = False
                                                      End If
                                                      Return
                                                  End If

                                                  _bacnetConsecutiveFails = 0
                                                  SetBacnetStatus("Connected", True)

                                                  ' Update DI LEDs
                                                  For i As Integer = 0 To 15
                                                      If bacnetLedDi(i) IsNot Nothing Then
                                                          bacnetLedDi(i).BackColor = If(di(i), Color.LimeGreen, Color.DarkRed)
                                                      End If
                                                      If bacnetLedText(i) IsNot Nothing Then
                                                          bacnetLedText(i).Text = If(di(i), "ON", "OFF")
                                                      End If
                                                  Next

                                                  ' Update DO checkboxes without writing back
                                                  _bacnetSuppressWrites = True
                                                  For i As Integer = 0 To 15
                                                      If bacnetChkDo(i) IsNot Nothing Then
                                                          ' UI: Checked = ON
                                                          Dim uiState As Boolean = If(BACNET_OUTPUT_ACTIVE_LOW, Not doo(i), doo(i))
                                                          bacnetChkDo(i).Checked = uiState
                                                      End If
                                                  Next
                                                  _bacnetSuppressWrites = False

                                                  ' Update Analog/Sensors table
                                                  If _dtAnalog IsNot Nothing Then
                                                      SetKV(_dtAnalog, "A1 (GPIO36) Voltage (V)", FmtNum(ai(0)))
                                                      SetKV(_dtAnalog, "A2 (GPIO34) Voltage (V)", FmtNum(ai(1)))
                                                      SetKV(_dtAnalog, "A3 (GPIO35) Voltage (V)", FmtNum(ai(2)))
                                                      SetKV(_dtAnalog, "A4 (GPIO39) Voltage (V)", FmtNum(ai(3)))
                                                      SetKV(_dtAnalog, "DHT1 Temp (°C)", FmtNum(ai(4)))
                                                      SetKV(_dtAnalog, "DHT1 Humidity (%)", FmtNum(ai(5)))
                                                      SetKV(_dtAnalog, "DHT2 Temp (°C)", FmtNum(ai(6)))
                                                      SetKV(_dtAnalog, "DHT2 Humidity (%)", FmtNum(ai(7)))
                                                      SetKV(_dtAnalog, "DS18B20 Temp (°C)", FmtNum(ai(8)))
                                                  End If

                                                  If needStatic Then
                                                      RefreshBacnetStaticInfo()
                                                  End If

                                              End Sub, Action))
                     End Sub)
        End Sub

        Private Function FmtNum(v As Double) As String
            If Double.IsNaN(v) OrElse Double.IsInfinity(v) Then Return "-"
            Return v.ToString("0.###", Globalization.CultureInfo.InvariantCulture)
        End Function

        Private Sub EnsureInstanceBases()
            If _baseKnown Then Return
            If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then Return

            ' Try BO instance 1 then 0
            Dim tmp As Object = Nothing
            If _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_OUTPUT, 1UI, tmp) Then
                _boBase = 1UI
            ElseIf _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_OUTPUT, 0UI, tmp) Then
                _boBase = 0UI
            Else
                _boBase = 1UI
            End If

            ' Try BI instance 1 then 0
            tmp = Nothing
            If _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_INPUT, 1UI, tmp) Then
                _biBase = 1UI
            ElseIf _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_BINARY_INPUT, 0UI, tmp) Then
                _biBase = 0UI
            Else
                _biBase = 1UI
            End If

            ' Try AI instance 1 then 0
            tmp = Nothing
            If _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_ANALOG_INPUT, 1UI, tmp) Then
                _aiBase = 1UI
            ElseIf _bacnet.TryReadPresentValue(BacnetObjectTypes.OBJECT_ANALOG_INPUT, 0UI, tmp) Then
                _aiBase = 0UI
            Else
                _aiBase = 1UI
            End If

            _baseKnown = True
        End Sub

        Private Sub RefreshBacnetStaticInfo()
            If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then Return

            ' --- Board fields ---
            Dim name As String = ""
            Dim desc As String = ""
            Dim loc As String = ""
            Dim fw As String = ""
            Dim model As String = ""
            Dim vendor As String = ""
            Dim serial As String = ""
            Dim mac As String = ""
            Dim hwVer As String = ""
            Dim yearDev As String = ""

            
            Dim subnetMask As String = ""
            Dim gw As String = ""
            Dim dns As String = ""
            Dim apSsid As String = ""
            Dim apPass As String = ""
            Dim apIp As String = ""
' Phase-1: Read static device/network properties using RPM (single request)
Dim devInfo As Dictionary(Of BacnetPropertyIds, String) = Nothing
Dim gotDevInfo As Boolean = False
Try
    gotDevInfo = _bacnet.TryReadDeviceInfoRPM(devInfo)
Catch
    gotDevInfo = False
End Try

If gotDevInfo AndAlso devInfo IsNot Nothing Then
    devInfo.TryGetValue(BacnetPropertyIds.PROP_OBJECT_NAME, name)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_DESCRIPTION, desc)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_LOCATION, loc)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MODEL_NAME, model)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_VENDOR_NAME, vendor)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_FIRMWARE_REVISION, fw)

    devInfo.TryGetValue(BacnetPropertyIds.PROP_SERIAL_NUMBER, serial)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_MAC_ADDRESS, mac)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_HARDWARE_VER, hwVer)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_YEAR_DEV, yearDev)

    ' --- Network fields ---
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_SUBNET_MASK, subnetMask)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_GATEWAY, gw)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_DNS1, dns)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_AP_SSID, apSsid)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_AP_PASSWORD, apPass)
    devInfo.TryGetValue(BacnetPropertyIds.PROP_MESA_AP_IP, apIp)

Else
_bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_OBJECT_NAME, name)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_DESCRIPTION, desc)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_LOCATION, loc)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MODEL_NAME, model)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_VENDOR_NAME, vendor)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_FIRMWARE_REVISION, fw)

            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_SERIAL_NUMBER, serial)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_MAC_ADDRESS, mac)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_HARDWARE_VER, hwVer)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_YEAR_DEV, yearDev)

            ' --- Network fields ---
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_SUBNET_MASK, subnetMask)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_GATEWAY, gw)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_DNS1, dns)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_AP_SSID, apSsid)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_AP_PASSWORD, apPass)
            _bacnet.TryReadDevicePropertyString(BacnetPropertyIds.PROP_MESA_AP_IP, apIp)
End If



            ' Apply to grids (keep last known values when read is empty)
            If Not String.IsNullOrWhiteSpace(name) Then SetKV(_dtBoard, "Device Name", name)
            If Not String.IsNullOrWhiteSpace(desc) Then SetKV(_dtBoard, "Device Description", desc)
            If Not String.IsNullOrWhiteSpace(loc) Then SetKV(_dtBoard, "Device Location", loc)
            If Not String.IsNullOrWhiteSpace(model) Then SetKV(_dtBoard, "Board Name", model)
            If Not String.IsNullOrWhiteSpace(serial) Then SetKV(_dtBoard, "Serial Number", serial)
            If Not String.IsNullOrWhiteSpace(mac) Then SetKV(_dtBoard, "Board MAC Address", mac)
            If Not String.IsNullOrWhiteSpace(vendor) Then SetKV(_dtBoard, "Manufacturer", vendor)
            If Not String.IsNullOrWhiteSpace(fw) Then SetKV(_dtBoard, "Firmware Version", fw)
            If Not String.IsNullOrWhiteSpace(hwVer) Then SetKV(_dtBoard, "Hardware Version", hwVer)
            If Not String.IsNullOrWhiteSpace(yearDev) Then SetKV(_dtBoard, "Year of Development", yearDev)

            If Not String.IsNullOrWhiteSpace(subnetMask) Then SetKV(_dtNet, "Subnet Mask", subnetMask)
            If Not String.IsNullOrWhiteSpace(gw) Then SetKV(_dtNet, "Gateway", gw)
            If Not String.IsNullOrWhiteSpace(dns) Then SetKV(_dtNet, "DNS", dns)
            If Not String.IsNullOrWhiteSpace(apSsid) Then SetKV(_dtNet, "AP SSID", apSsid)
            If Not String.IsNullOrWhiteSpace(apPass) Then SetKV(_dtNet, "AP Password", apPass)
            If Not String.IsNullOrWhiteSpace(apIp) Then SetKV(_dtNet, "AP IP Address", apIp)

            _lastStaticInfoRead = DateTime.Now
        End Sub

        Private Sub BacnetOutputChanged(index As Integer)
            If _bacnetSuppressWrites Then Return
            If _bacnet Is Nothing OrElse Not _bacnet.IsConnected Then Return

            ' UI: Checked = ON
            Dim desiredUi As Boolean = bacnetChkDo(index).Checked
            Dim desiredDevice As Boolean = If(BACNET_OUTPUT_ACTIVE_LOW, Not desiredUi, desiredUi)
            Dim inst As UInteger = _boBase + CUInt(index)

            Task.Run(Sub()
                         Dim ok As Boolean = _bacnet.TryWriteBinaryOutput(inst, desiredDevice)
                         Me.BeginInvoke(CType(Sub()
                                                  If ok Then
                                                      SetBacnetStatus("Write OK: DO" & (index + 1).ToString() & "=" & If(desiredUi, "ON", "OFF"), True)
                                                  Else
                                                      SetBacnetStatus("Write FAIL: DO" & (index + 1).ToString(), False)
                                                  End If
                                              End Sub, Action))
                     End Sub)
        End Sub

        Private Sub SetBacnetStatus(text As String, good As Boolean)
            lblBacnetStatus.Text = text
            lblBacnetStatus.ForeColor = If(good, Color.DarkGreen, Color.DarkRed)
        End Sub

    End Class

End Namespace
