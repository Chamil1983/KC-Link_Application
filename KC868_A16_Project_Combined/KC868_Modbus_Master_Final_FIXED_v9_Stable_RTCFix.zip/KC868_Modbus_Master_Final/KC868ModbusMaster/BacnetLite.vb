Option Strict On
Option Explicit On

' -------------------------------------------------------------------------------------------------
' BacnetLite.vb
' -------------------------------------------------------------------------------------------------
' Minimal, self-contained BACnet/IP client implementation designed for:
'   - Reading Present_Value from BI/BO/AI
'   - Writing Present_Value to BO
'   - Reading Device string properties (Name/Description/Location/Firmware/Model)
'
' This file is provided to make the project compile WITHOUT external NuGet dependencies.
' It intentionally implements only the small subset required by BacnetManager.vb.
'
' Namespace matches the commonly used System.IO.BACnet API surface so existing code
' (BacnetManager/MainForm.Bacnet) can remain unchanged.
'
Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Namespace System.IO.BACnet

    ' ---------------------------- Public enums used by BacnetManager ----------------------------
    Public Enum BacnetAddressTypes
        IP = 0
    End Enum

    Public Enum BacnetObjectTypes
        OBJECT_ANALOG_INPUT = 0
        OBJECT_BINARY_INPUT = 3
        OBJECT_BINARY_OUTPUT = 4
        OBJECT_DEVICE = 8
    End Enum

    Public Enum BacnetPropertyIds
        PROP_OBJECT_IDENTIFIER = 75
        PROP_OBJECT_NAME = 77
        PROP_OBJECT_TYPE = 79
        PROP_PRESENT_VALUE = 85
        PROP_DESCRIPTION = 28
        PROP_LOCATION = 58
        PROP_MODEL_NAME = 70
        PROP_VENDOR_NAME = 121
        PROP_VENDOR_IDENTIFIER = 120
        PROP_FIRMWARE_REVISION = 44
    End Enum

    Public Enum BacnetApplicationTags
        BACNET_APPLICATION_TAG_NULL = 0
        BACNET_APPLICATION_TAG_BOOLEAN = 1
        BACNET_APPLICATION_TAG_UNSIGNED_INT = 2
        BACNET_APPLICATION_TAG_SIGNED_INT = 3
        BACNET_APPLICATION_TAG_REAL = 4
        BACNET_APPLICATION_TAG_DOUBLE = 5
        BACNET_APPLICATION_TAG_OCTET_STRING = 6
        BACNET_APPLICATION_TAG_CHARACTER_STRING = 7
        BACNET_APPLICATION_TAG_BIT_STRING = 8
        BACNET_APPLICATION_TAG_ENUMERATED = 9
    End Enum

    ' ---------------------------- Public simple types used by BacnetManager ---------------------
    Public Structure BacnetObjectId
        Public ReadOnly Type As BacnetObjectTypes
        Public ReadOnly Instance As UInteger

        Public Sub New(objType As BacnetObjectTypes, instance As UInteger)
            Me.Type = objType
            Me.Instance = instance
        End Sub
    End Structure

    Public Class BacnetValue
        Public ReadOnly Tag As BacnetApplicationTags
        Public ReadOnly Value As Object

        Public Sub New(tag As BacnetApplicationTags, value As Object)
            Me.Tag = tag
            Me.Value = value
        End Sub
    End Class

    Public Class BacnetAddress
        Public ReadOnly Property AddressType As BacnetAddressTypes
        Public ReadOnly Property IPEndPoint As IPEndPoint

        Public Sub New(addressType As BacnetAddressTypes, address As String)
            Me.AddressType = addressType
            Me.IPEndPoint = ParseIpEndPoint(address)
        End Sub

        Public Sub New(addressType As BacnetAddressTypes, ep As IPEndPoint)
            Me.AddressType = addressType
            Me.IPEndPoint = ep
        End Sub

        Private Shared Function ParseIpEndPoint(s As String) As IPEndPoint
            If String.IsNullOrWhiteSpace(s) Then Throw New ArgumentException("Empty address")
            Dim parts = s.Split(":"c)
            Dim ip As IPAddress = IPAddress.Parse(parts(0).Trim())
            Dim port As Integer = 47808
            If parts.Length > 1 Then
                Integer.TryParse(parts(1).Trim(), port)
            End If
            Return New IPEndPoint(ip, port)
        End Function

        Public Overrides Function ToString() As String
            Return IPEndPoint.Address.ToString() & ":" & IPEndPoint.Port.ToString(CultureInfo.InvariantCulture)
        End Function
    End Class

    Public Class BacnetIpUdpProtocolTransport
        Public ReadOnly Property Port As Integer
        Public ReadOnly Property UseSharedSocket As Boolean

        Public Sub New(port As Integer, useSharedSocket As Boolean)
            Me.Port = port
            Me.UseSharedSocket = useSharedSocket
        End Sub
    End Class

    ' ---------------------------- Minimal BacnetClient (subset) ---------------------------------
    Public Class BacnetClient
        Implements IDisposable

        Private Const BVLL_TYPE As Byte = &H81
        Private Const BVLL_FUNC_ORIGINAL_UNICAST_NPDU As Byte = &HA

        Private Const BACNET_UDP_DEFAULT_PORT As Integer = &HBAC0 ' 47808
        Private Const NPDU_VERSION As Byte = &H1
        Private Const NPDU_CONTROL_EXPECTING_REPLY As Byte = &H4

        Private Const PDU_TYPE_CONFIRMED_SERVICE_REQUEST As Byte = &H0
        Private Const PDU_TYPE_COMPLEX_ACK As Byte = &H30
        Private Const PDU_TYPE_SIMPLE_ACK As Byte = &H20
        Private Const PDU_TYPE_ERROR As Byte = &H50

        Private Const SERVICE_CONFIRMED_READ_PROPERTY As Byte = &HC
        Private Const SERVICE_CONFIRMED_WRITE_PROPERTY As Byte = &HF

        Private ReadOnly _sync As New Object()
        Private ReadOnly _transport As BacnetIpUdpProtocolTransport
        Private _udp As UdpClient
        Private _invokeId As Byte = 1
        Private _timeoutMs As Integer = 800

        Public Sub New(transport As BacnetIpUdpProtocolTransport)
            _transport = transport
        End Sub

        Public Sub Start()
            SyncLock _sync
                If _udp IsNot Nothing Then Return
                Try
                    Dim localPort As Integer = If(_transport IsNot Nothing AndAlso _transport.Port > 0, _transport.Port, BACNET_UDP_DEFAULT_PORT)
                    _udp = New UdpClient(localPort)
                Catch
                    ' If port is busy, bind to ephemeral
                    _udp = New UdpClient(0)
                End Try
                _udp.Client.ReceiveTimeout = _timeoutMs
                _udp.Client.SendTimeout = _timeoutMs
            End SyncLock
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            SyncLock _sync
                If _udp IsNot Nothing Then
                    Try
                        _udp.Close()
                    Catch
                    End Try
                    _udp = Nothing
                End If
            End SyncLock
        End Sub

        ' -------------------- ReadProperty (Present_Value) --------------------
        Public Function ReadPropertyRequest(adr As BacnetAddress,
                                            objId As BacnetObjectId,
                                            propertyId As BacnetPropertyIds,
                                            ByRef values As IList(Of BacnetValue)) As Boolean
            values = Nothing
            Dim udp = GetUdp()
            If udp Is Nothing OrElse adr Is Nothing Then Return False

            Dim invoke As Byte = NextInvokeId()
            Dim apdu As Byte() = BuildReadPropertyApdu(invoke, objId, CUInt(propertyId))
            Dim packet As Byte() = BuildBacnetIpPacket(apdu)

            Dim resp As Byte() = SendAndReceive(udp, adr.IPEndPoint, packet, invoke)
            If resp Is Nothing OrElse resp.Length < 10 Then Return False

            Dim val As BacnetValue = Nothing
            If Not TryParseReadPropertyAck(resp, invoke, val) Then
                Return False
            End If

            values = New List(Of BacnetValue) From {val}
            Return True
        End Function

        ' -------------------- WriteProperty (BO Present_Value) --------------------
        Public Function WritePropertyRequest(adr As BacnetAddress,
                                             objId As BacnetObjectId,
                                             propertyId As BacnetPropertyIds,
                                             values() As BacnetValue) As Boolean
            Dim udp = GetUdp()
            If udp Is Nothing OrElse adr Is Nothing Then Return False
            If values Is Nothing OrElse values.Length = 0 Then Return False

            Dim invoke As Byte = NextInvokeId()
            Dim apdu As Byte() = BuildWritePropertyApdu(invoke, objId, CUInt(propertyId), values(0))
            Dim packet As Byte() = BuildBacnetIpPacket(apdu)

            Dim resp As Byte() = SendAndReceive(udp, adr.IPEndPoint, packet, invoke)
            If resp Is Nothing OrElse resp.Length < 10 Then Return False

            Return IsSimpleAckFor(resp, invoke, SERVICE_CONFIRMED_WRITE_PROPERTY)
        End Function

        ' -------------------- Internal helpers --------------------
        Private Function GetUdp() As UdpClient
            SyncLock _sync
                Return _udp
            End SyncLock
        End Function

        Private Function NextInvokeId() As Byte
            SyncLock _sync
                Dim v = _invokeId
                _invokeId = CByte((_invokeId + 1) And &HFF)
                If _invokeId = 0 Then _invokeId = 1
                Return v
            End SyncLock
        End Function

        Private Function SendAndReceive(udp As UdpClient, remote As IPEndPoint, request As Byte(), invokeId As Byte) As Byte()
            Try
                udp.Send(request, request.Length, remote)

                ' Receive until we find matching InvokeID or timeout
                Dim start As Integer = Environment.TickCount
                Do
                    Dim r As IPEndPoint = Nothing
                    Dim data As Byte() = udp.Receive(r)
                    If data IsNot Nothing AndAlso data.Length > 12 Then
                        If ContainsInvokeId(data, invokeId) Then
                            Return data
                        End If
                    End If
                Loop While (Environment.TickCount - start) < _timeoutMs
            Catch
            End Try
            Return Nothing
        End Function

        Private Shared Function ContainsInvokeId(data As Byte(), invokeId As Byte) As Boolean
            ' Heuristic: invokeId typically appears near APDU header
            For i As Integer = 0 To Math.Min(data.Length - 1, 64)
                If data(i) = invokeId Then Return True
            Next
            Return False
        End Function

        Private Shared Function BuildBacnetIpPacket(apdu As Byte()) As Byte()
            ' BVLL + NPDU + APDU
            Dim npdu As Byte() = {NPDU_VERSION, NPDU_CONTROL_EXPECTING_REPLY}
            Dim totalLen As Integer = 4 + npdu.Length + apdu.Length

            Dim p(totalLen - 1) As Byte
            p(0) = BVLL_TYPE
            p(1) = BVLL_FUNC_ORIGINAL_UNICAST_NPDU
            p(2) = CByte((totalLen >> 8) And &HFF)
            p(3) = CByte(totalLen And &HFF)

            Buffer.BlockCopy(npdu, 0, p, 4, npdu.Length)
            Buffer.BlockCopy(apdu, 0, p, 4 + npdu.Length, apdu.Length)
            Return p
        End Function

        Private Shared Function BuildReadPropertyApdu(invokeId As Byte, objId As BacnetObjectId, propertyId As UInteger) As Byte()
            Dim buf As New List(Of Byte)(64)

            ' Confirmed Service Request: [0]=0x00, [1]=seg/maxapdu, [2]=invoke, [3]=service
            buf.Add(&H0)          ' Confirmed
            buf.Add(&H5)          ' "max seg/max apdu" (ignored by ESP32 parser)
            buf.Add(invokeId)
            buf.Add(SERVICE_CONFIRMED_READ_PROPERTY)

            ' Context 0: Object Identifier (4 bytes)
            buf.Add(ContextTagByte(0, 4))
            Dim oid As UInteger = EncodeObjectId(objId.Type, objId.Instance)
            buf.Add(CByte((oid >> 24) And &HFF))
            buf.Add(CByte((oid >> 16) And &HFF))
            buf.Add(CByte((oid >> 8) And &HFF))
            buf.Add(CByte(oid And &HFF))

            ' Context 1: Property Identifier (unsigned)
            Dim propBytes As Byte() = EncodeUnsigned(propertyId)
            buf.Add(ContextTagByte(1, propBytes.Length))
            buf.AddRange(propBytes)

            Return buf.ToArray()
        End Function

        Private Shared Function BuildWritePropertyApdu(invokeId As Byte, objId As BacnetObjectId, propertyId As UInteger, value As BacnetValue) As Byte()
            Dim buf As New List(Of Byte)(96)

            buf.Add(&H0)
            buf.Add(&H5)
            buf.Add(invokeId)
            buf.Add(SERVICE_CONFIRMED_WRITE_PROPERTY)

            ' Context 0: Object Identifier
            buf.Add(ContextTagByte(0, 4))
            Dim oid As UInteger = EncodeObjectId(objId.Type, objId.Instance)
            buf.Add(CByte((oid >> 24) And &HFF))
            buf.Add(CByte((oid >> 16) And &HFF))
            buf.Add(CByte((oid >> 8) And &HFF))
            buf.Add(CByte(oid And &HFF))

            ' Context 1: Property Identifier
            Dim propBytes As Byte() = EncodeUnsigned(propertyId)
            buf.Add(ContextTagByte(1, propBytes.Length))
            buf.AddRange(propBytes)

            ' Context 3: opening tag
            buf.Add(OpeningTag(3))
            buf.AddRange(EncodeApplicationValue(value))
            buf.Add(ClosingTag(3))

            Return buf.ToArray()
        End Function

        Private Shared Function EncodeApplicationValue(v As BacnetValue) As Byte()
            Dim outBytes As New List(Of Byte)(16)
            Select Case v.Tag
                Case BacnetApplicationTags.BACNET_APPLICATION_TAG_ENUMERATED
                    Dim n As UInteger = Convert.ToUInt32(v.Value, CultureInfo.InvariantCulture)
                    Dim b As Byte() = EncodeUnsigned(n)
                    outBytes.Add(ApplicationTagByte(CInt(BacnetApplicationTags.BACNET_APPLICATION_TAG_ENUMERATED), b.Length))
                    outBytes.AddRange(b)
                Case BacnetApplicationTags.BACNET_APPLICATION_TAG_REAL
                    Dim f As Single = Convert.ToSingle(v.Value, CultureInfo.InvariantCulture)
                    Dim b As Byte() = EncodeReal(f)
                    outBytes.Add(ApplicationTagByte(CInt(BacnetApplicationTags.BACNET_APPLICATION_TAG_REAL), b.Length))
                    outBytes.AddRange(b)
                Case BacnetApplicationTags.BACNET_APPLICATION_TAG_BOOLEAN
                    Dim bval As Boolean = Convert.ToBoolean(v.Value, CultureInfo.InvariantCulture)
                    outBytes.Add(ApplicationTagByte(CInt(BacnetApplicationTags.BACNET_APPLICATION_TAG_BOOLEAN), 1))
                    outBytes.Add(CByte(If(bval, 1, 0)))
                Case Else
                    ' fallback enumerated
                    Dim n As UInteger = Convert.ToUInt32(v.Value, CultureInfo.InvariantCulture)
                    Dim b As Byte() = EncodeUnsigned(n)
                    outBytes.Add(ApplicationTagByte(CInt(BacnetApplicationTags.BACNET_APPLICATION_TAG_ENUMERATED), b.Length))
                    outBytes.AddRange(b)
            End Select
            Return outBytes.ToArray()
        End Function

        Private Shared Function TryParseReadPropertyAck(resp As Byte(), invokeId As Byte, ByRef outValue As BacnetValue) As Boolean
            outValue = Nothing

            ' Basic BVLL sanity
            If resp.Length < 10 Then Return False
            If resp(0) <> BVLL_TYPE Then Return False

            ' Skip BVLL (4)
            Dim offset As Integer = 4
            If offset + 2 >= resp.Length Then Return False

            ' NPDU
            If resp(offset) <> NPDU_VERSION Then Return False
            offset += 2

            ' APDU should be ComplexAck or Error
            If offset + 3 >= resp.Length Then Return False
            Dim pduType As Byte = CByte(resp(offset) And &HF0)
            If pduType = PDU_TYPE_ERROR Then Return False

            If pduType <> PDU_TYPE_COMPLEX_ACK Then
                Return False
            End If

            ' ComplexAck: [0]=0x30, [1]=invoke, [2]=service
            If resp(offset + 1) <> invokeId Then
                ' sometimes parser may place invoke later - continue scan
            End If
            offset += 3

            ' Find opening tag 3 (0x3E)
            Dim openIdx As Integer = Array.IndexOf(resp, CByte(&H3E), offset)
            If openIdx < 0 OrElse openIdx + 1 >= resp.Length Then Return False

            Dim i As Integer = openIdx + 1

            ' Application tag header
            Dim tag As Byte = resp(i)
            Dim tagNumber As Integer = (tag >> 4) And &HF
            Dim isContext As Boolean = ((tag And &H8) <> 0)
            Dim len As Integer = tag And &H7
            If isContext Then
                Return False
            End If

            i += 1
            If len = 5 Then
                If i >= resp.Length Then Return False
                len = resp(i)
                i += 1
            ElseIf len = 6 OrElse len = 7 Then
                Return False
            End If

            If i + len > resp.Length Then Return False

            Dim raw(len - 1) As Byte
            Buffer.BlockCopy(resp, i, raw, 0, len)

            Select Case tagNumber
                Case 9 ' ENUMERATED
                    Dim n As UInteger = DecodeUnsigned(raw)
                    outValue = New BacnetValue(BacnetApplicationTags.BACNET_APPLICATION_TAG_ENUMERATED, n)
                    Return True
                Case 4 ' REAL
                    If raw.Length <> 4 Then Return False
                    Dim f As Single = DecodeReal(raw)
                    outValue = New BacnetValue(BacnetApplicationTags.BACNET_APPLICATION_TAG_REAL, f)
                    Return True
                Case 1 ' BOOLEAN
                    Dim b As Boolean = (raw.Length > 0 AndAlso raw(0) <> 0)
                    outValue = New BacnetValue(BacnetApplicationTags.BACNET_APPLICATION_TAG_BOOLEAN, b)
                    Return True
                Case 7 ' CHARACTER STRING
                    If raw.Length < 1 Then Return False
                    Dim enc As Byte = raw(0)
                    Dim txtBytes As Byte() = raw.Skip(1).ToArray()
                    Dim txt As String = Encoding.UTF8.GetString(txtBytes)
                    outValue = New BacnetValue(BacnetApplicationTags.BACNET_APPLICATION_TAG_CHARACTER_STRING, txt)
                    Return True
                Case Else
                    ' Unknown - return as raw bytes
                    outValue = New BacnetValue(BacnetApplicationTags.BACNET_APPLICATION_TAG_OCTET_STRING, raw)
                    Return True
            End Select
        End Function

        Private Shared Function IsSimpleAckFor(resp As Byte(), invokeId As Byte, serviceChoice As Byte) As Boolean
            If resp Is Nothing OrElse resp.Length < 12 Then Return False
            If resp(0) <> BVLL_TYPE Then Return False

            Dim offset As Integer = 4
            If resp(offset) <> NPDU_VERSION Then Return False
            offset += 2
            If offset + 2 >= resp.Length Then Return False
            Dim pduType As Byte = CByte(resp(offset) And &HF0)
            If pduType = PDU_TYPE_ERROR Then Return False
            If pduType <> PDU_TYPE_SIMPLE_ACK Then Return False

            ' SimpleAck: [0]=0x20, [1]=invoke, [2]=service
            Return (resp(offset + 1) = invokeId AndAlso resp(offset + 2) = serviceChoice)
        End Function

        ' -------------------- BACnet Tag / Value utilities --------------------
        Private Shared Function EncodeObjectId(objType As BacnetObjectTypes, instance As UInteger) As UInteger
            ' (type << 22) | instance
            Return (CUInt(CInt(objType)) << 22) Or (instance And &H3FFFFFUI)
        End Function

        Private Shared Function EncodeUnsigned(v As UInteger) As Byte()
            If v <= &HFFUI Then
                Return New Byte() {CByte(v And &HFFUI)}
            ElseIf v <= &HFFFFUI Then
                Return New Byte() {CByte((v >> 8) And &HFFUI), CByte(v And &HFFUI)}
            ElseIf v <= &HFFFFFFUI Then
                Return New Byte() {CByte((v >> 16) And &HFFUI), CByte((v >> 8) And &HFFUI), CByte(v And &HFFUI)}
            Else
                Return New Byte() {CByte((v >> 24) And &HFFUI), CByte((v >> 16) And &HFFUI), CByte((v >> 8) And &HFFUI), CByte(v And &HFFUI)}
            End If
        End Function

        Private Shared Function DecodeUnsigned(b As Byte()) As UInteger
            Dim v As UInteger = 0UI
            For i As Integer = 0 To b.Length - 1
                v = (v << 8) Or b(i)
            Next
            Return v
        End Function

        Private Shared Function EncodeReal(f As Single) As Byte()
            Dim bytes As Byte() = BitConverter.GetBytes(f)
            If BitConverter.IsLittleEndian Then Array.Reverse(bytes)
            Return bytes
        End Function

        Private Shared Function DecodeReal(b As Byte()) As Single
            Dim bytes As Byte() = CType(b.Clone(), Byte())
            If BitConverter.IsLittleEndian Then Array.Reverse(bytes)
            Return BitConverter.ToSingle(bytes, 0)
        End Function

        Private Shared Function ContextTagByte(tagNumber As Integer, length As Integer) As Byte
            ' Context tag: (tag<<4) | 0x08 | len
            Return CByte(((tagNumber And &HF) << 4) Or &H8 Or (length And &H7))
        End Function

        Private Shared Function ApplicationTagByte(tagNumber As Integer, length As Integer) As Byte
            Return CByte(((tagNumber And &HF) << 4) Or (length And &H7))
        End Function

        Private Shared Function OpeningTag(tagNumber As Integer) As Byte
            ' Opening tag: len = 6
            Return CByte(((tagNumber And &HF) << 4) Or &H8 Or &H6)
        End Function

        Private Shared Function ClosingTag(tagNumber As Integer) As Byte
            ' Closing tag: len = 7
            Return CByte(((tagNumber And &HF) << 4) Or &H8 Or &H7)
        End Function

    End Class

End Namespace
