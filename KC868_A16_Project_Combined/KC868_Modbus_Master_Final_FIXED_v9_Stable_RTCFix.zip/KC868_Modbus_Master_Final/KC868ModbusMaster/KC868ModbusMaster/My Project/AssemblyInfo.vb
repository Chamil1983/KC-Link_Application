Option Strict On
Option Explicit On

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("KC868ModbusMaster")>
<Assembly: AssemblyDescription("KC868 A16 Modbus RTU Master GUI")>
<Assembly: AssemblyCompany("Microcode Engineering")>
<Assembly: AssemblyProduct("KC868ModbusMaster")>
<Assembly: AssemblyCopyright("Copyright © 2026")>
<Assembly: ComVisible(False)>
<Assembly: Guid("7c4a59e1-3950-4d1a-a8b7-f6433e169764")>
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
