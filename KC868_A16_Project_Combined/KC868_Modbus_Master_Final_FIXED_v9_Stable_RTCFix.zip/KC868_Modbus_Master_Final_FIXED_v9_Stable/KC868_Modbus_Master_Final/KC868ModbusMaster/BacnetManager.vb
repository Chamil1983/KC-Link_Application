Option Strict On
Option Explicit On

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading
Imports System.Linq

Namespace KC868ModbusMaster

    ' -----------------------------------------------------------------------------
    ' Minimal BACnet/IP (UDP) client implementation
    ' -----------------------------------------------------------------------------
    ' This replaces the external System.IO.BACnet dependency so the project compiles
    ' and runs without requiring NuGet restores on customer machines.
    '
    ' Supported operations:
    '  - Confirmed ReadProperty (Present_Value + basic device strings)
    '  - Confirmed WriteProperty (Binary Output Present_Value)
    '
    ' The Arduino firmware must expose standard objects:
    '  - BI / BO / AI with Present_Value
    '  - Device object with Object_Name / Description / Location / Model_Name / Firmware_Revision
    '
    ' NOTE: This is a pragmatic subset designed specifically for KC868-A16 GUI control.

    Public Enum BacnetObjectTypes As UInteger
        OBJECT_ANALOG_INPUT = 0UI
        OBJECT_ANALOG_OUTPUT = 1UI
        OBJECT_ANALOG_VALUE = 2UI
        OBJECT_BINARY_INPUT = 3UI
        OBJECT_BINARY_OUTPUT = 4UI
        OBJECT_BINARY_VALUE = 5UI
        OBJECT_DEVICE = 8UI
    End Enum

    Public Enum BacnetPropertyIds As UInteger
        PROP_DESCRIPTION = 28UI
        PROP_FIRMWARE_REVISION = 44UI
        PROP_LOCATION = 58UI
        PROP_MODEL_NAME = 70UI
        PROP_OBJECT_NAME = 77UI
        PROP_PRESENT_VALUE = 85UI
        PROP_VENDOR_NAME = 121UI
        PROP_SERIAL_NUMBER = 372UI

        ' ---- Vendor properties (Microcode / KC868) ----
        PROP_MESA_MAC_ADDRESS = 512UI
        PROP_MESA_HARDWARE_VER = 513UI
        PROP_MESA_YEAR_DEV = 514UI
        PROP_MESA_SUBNET_MASK = 515UI
        PROP_MESA_GATEWAY = 516UI
        PROP_MESA_DNS1 = 517UI
        PROP_MESA_AP_SSID = 518UI
        PROP_MESA_AP_PASSWORD = 519UI
        PROP_MESA_AP_IP = 520UI
    End Enum

    ''' <summary>
    ''' Simple structure used by the Discovery picker (Who-Is / I-Am).
    ''' </summary>
    Public Class BacnetDiscoveredDevice
        Public Property Address As String
        Public Property Port As Integer
        Public Property DeviceInstance As UInteger

        Public Sub New(address As String, port As Integer, deviceInstance As UInteger)
            Me.Address = address
            Me.Port = port
            Me.DeviceInstance = deviceInstance
        End Sub

        Public Overrides Function ToString() As String
            Return String.Format(CultureInfo.InvariantCulture, "{0}  (ID={1}, Port={2})", Address, DeviceInstance, Port)
        End Function
    End Class

    Public Class BacnetManager
        Implements IDisposable

        Private ReadOnly _sync As New Object()

        Private _udp As UdpClient
        Private _remote As IPEndPoint
        Private _deviceInstance As UInteger = 88160UI
        Private _localPort As Integer = &HBAC0 ' 47808
        Private _remotePort As Integer = &HBAC0

        ' --- BACnet UDP receive timeout (ms) ---
        Private _timeoutMs As Integer = 1500

        Private _invokeId As Byte = 1

        Public ReadOnly Property IsStarted As Boolean
            Get
                SyncLock _sync
                    Return _udp IsNot Nothing
                End SyncLock
            End Get
        End Property

        Public ReadOnly Property IsConnected As Boolean
            Get
                SyncLock _sync
                    Return _udp IsNot Nothing AndAlso _remote IsNot Nothing
                End SyncLock
            End Get
        End Property

        Public Property DeviceInstance As UInteger
            Get
                SyncLock _sync
                    Return _deviceInstance
                End SyncLock
            End Get
            Set(value As UInteger)
                SyncLock _sync
                    _deviceInstance = value
                End SyncLock
            End Set
        End Property

        Public Property LocalPort As Integer
            Get
                SyncLock _sync
                    Return _localPort
                End SyncLock
            End Get
            Set(value As Integer)
                SyncLock _sync
                    _localPort = value
                End SyncLock
            End Set
        End Property

        Public Property RemotePort As Integer
            Get
                SyncLock _sync
                    Return _remotePort
                End SyncLock
            End Get
            Set(value As Integer)
                SyncLock _sync
                    _remotePort = value
                End SyncLock
            End Set
        End Property

        Public Sub Start()
            SyncLock _sync
                If _udp IsNot Nothing Then Return
                _udp = New UdpClient(_localPort)
                _udp.Client.ReceiveTimeout = 1500
                _udp.Client.SendTimeout = 1500
            End SyncLock
        End Sub

        Public Sub Connect(remoteIp As String, Optional remotePort As Integer = &HBAC0, Optional deviceInstance As UInteger = 88160UI)
            If String.IsNullOrWhiteSpace(remoteIp) Then Throw New ArgumentException("remoteIp cannot be empty")

            SyncLock _sync
                _remotePort = remotePort
                _deviceInstance = deviceInstance
            End SyncLock

            If Not IsStarted Then Me.Start()

            Dim ip As IPAddress = IPAddress.Parse(remoteIp.Trim())
            SyncLock _sync
                _remote = New IPEndPoint(ip, remotePort)
            End SyncLock
        End Sub

        Public Sub Disconnect()
            SyncLock _sync
                _remote = Nothing
                If _udp IsNot Nothing Then
                    Try
                        _udp.Close()
                    Catch
                    End Try
                    _udp = Nothing
                End If
            End SyncLock
        End Sub

        ' ---------------------------------------------------------------------
        ' Discovery + BBMD (optional)
        ' ---------------------------------------------------------------------

        Public Function RegisterForeignDevice(bbmdIp As String, bbmdPort As Integer, ttlSeconds As Integer) As Boolean
            If String.IsNullOrWhiteSpace(bbmdIp) Then Return False
            If Not IsStarted Then Me.Start()

            Dim udpLocal As UdpClient = Nothing
            SyncLock _sync
                udpLocal = _udp
            End SyncLock
            If udpLocal Is Nothing Then Return False

            Dim bbmdEp As New IPEndPoint(IPAddress.Parse(bbmdIp.Trim()), bbmdPort)
            Dim pkt As Byte() = BuildBvlcRegisterForeignDevicePacket(ttlSeconds)

            Try
                udpLocal.Send(pkt, pkt.Length, bbmdEp)
                Dim ep As New IPEndPoint(IPAddress.Any, 0)
                Dim resp As Byte() = udpLocal.Receive(ep)
                Return ParseBvlcResultOk(resp)
            Catch
                Return False
            End Try
        End Function

        ''' <summary>
        ''' Broadcast Who-Is and collect I-Am replies for a short time window.
        ''' If useBbmd=True, the same Who-Is is also unicasted to the BBMD.
        ''' </summary>
        Public Function DiscoverDevices(timeoutMs As Integer, Optional useBbmd As Boolean = False, Optional bbmdIp As String = "", Optional bbmdPort As Integer = &HBAC0) As List(Of BacnetDiscoveredDevice)
            Dim results As New List(Of BacnetDiscoveredDevice)()
            If timeoutMs < 250 Then timeoutMs = 250
            If Not IsStarted Then Me.Start()

            Dim udpLocal As UdpClient = Nothing
            SyncLock _sync
                udpLocal = _udp
            End SyncLock
            If udpLocal Is Nothing Then Return results

            udpLocal.EnableBroadcast = True

            Dim whoIsApdu As Byte() = BuildWhoIsApdu()
            Dim bcastPkt As Byte() = WrapBacnetIpBroadcast(whoIsApdu)

            Try
                ' Local subnet broadcast
                udpLocal.Send(bcastPkt, bcastPkt.Length, New IPEndPoint(IPAddress.Broadcast, _remotePort))
            Catch
            End Try

            If useBbmd AndAlso Not String.IsNullOrWhiteSpace(bbmdIp) Then
                Try
                    Dim bbmdEp As New IPEndPoint(IPAddress.Parse(bbmdIp.Trim()), bbmdPort)
                    Dim uniPkt As Byte() = WrapBacnetIpUnicast(whoIsApdu)
                    udpLocal.Send(uniPkt, uniPkt.Length, bbmdEp)
                Catch
                End Try
            End If

            ' Collect replies
            Dim tStart As DateTime = DateTime.UtcNow
            Dim origTimeout As Integer = udpLocal.Client.ReceiveTimeout
            udpLocal.Client.ReceiveTimeout = 200

            Do While (DateTime.UtcNow - tStart).TotalMilliseconds < timeoutMs
                Try
                    Dim ep As New IPEndPoint(IPAddress.Any, 0)
                    Dim resp As Byte() = udpLocal.Receive(ep)
                    Dim devId As UInteger = 0UI
                    If TryParseIAm(resp, devId) Then
                        Dim addr As String = ep.Address.ToString()
                        Dim port As Integer = ep.Port
                        If Not results.Any(Function(x) x.DeviceInstance = devId AndAlso x.Address = addr) Then
                            results.Add(New BacnetDiscoveredDevice(addr, port, devId))
                        End If
                    End If
                Catch ex As SocketException
                    ' timeout chunk
                Catch
                End Try
            Loop

            udpLocal.Client.ReceiveTimeout = origTimeout
            Return results
        End Function

        Public Function TryReadPresentValue(objType As BacnetObjectTypes, instance As UInteger, ByRef outValue As Object) As Boolean
            Dim resp As Byte() = Nothing
            Dim invoke As Byte
            Dim ok As Boolean = SendReadProperty(objType, instance, BacnetPropertyIds.PROP_PRESENT_VALUE, invoke, resp)
            If Not ok OrElse resp Is Nothing Then Return False

            Dim pv As Object = Nothing
            If Not TryParseReadPropertyAck(resp, invoke, pv) Then Return False
            outValue = pv
            Return True
        End Function

        Public Function TryWriteBinaryOutput(instance As UInteger, state As Boolean) As Boolean
            Dim resp As Byte() = Nothing
            Dim invoke As Byte
            If Not SendWritePropertyBinaryOutput(instance, state, invoke, resp) Then Return False

            Return TryParseSimpleAck(resp, invoke, &H0F)
        End Function

        Public Function TryReadDevicePropertyString(propertyId As BacnetPropertyIds, ByRef outText As String) As Boolean
            Dim resp As Byte() = Nothing
            Dim invoke As Byte
            If Not SendReadProperty(BacnetObjectTypes.OBJECT_DEVICE, _deviceInstance, propertyId, invoke, resp) Then Return False

            Dim pv As Object = Nothing
            If Not TryParseReadPropertyAck(resp, invoke, pv) Then Return False

            outText = Convert.ToString(pv, CultureInfo.InvariantCulture)
            Return True
        End Function

        Public Function TryReadDevicePropertyNumber(propertyId As BacnetPropertyIds, ByRef outNumber As Double) As Boolean
            Dim resp As Byte() = Nothing
            Dim invoke As Byte
            If Not SendReadProperty(BacnetObjectTypes.OBJECT_DEVICE, _deviceInstance, propertyId, invoke, resp) Then Return False

            Dim pv As Object = Nothing
            If Not TryParseReadPropertyAck(resp, invoke, pv) Then Return False

            Dim d As Double
            If Double.TryParse(Convert.ToString(pv, CultureInfo.InvariantCulture), NumberStyles.Any, CultureInfo.InvariantCulture, d) Then
                outNumber = d
                Return True
            End If
            Return False
        End Function

        Public Shared Function ToBool(bacnetValue As Object) As Boolean
            If bacnetValue Is Nothing Then Return False
            If TypeOf bacnetValue Is Boolean Then Return CBool(bacnetValue)
            If TypeOf bacnetValue Is Integer Then Return CInt(bacnetValue) <> 0
            If TypeOf bacnetValue Is UInteger Then Return CUInt(bacnetValue) <> 0UI
            If TypeOf bacnetValue Is Byte Then Return CByte(bacnetValue) <> 0
            If TypeOf bacnetValue Is Short Then Return CShort(bacnetValue) <> 0S
            If TypeOf bacnetValue Is UShort Then Return CUShort(bacnetValue) <> 0US
            Dim s As String = bacnetValue.ToString().Trim()
            If String.Equals(s, "active", StringComparison.OrdinalIgnoreCase) Then Return True
            If String.Equals(s, "inactive", StringComparison.OrdinalIgnoreCase) Then Return False
            Dim n As Integer
            If Integer.TryParse(s, n) Then Return n <> 0
            Return False
        End Function

        Public Sub Dispose() Implements IDisposable.Dispose
            Disconnect()
        End Sub

        ' -------------------------------------------------------------------------
        ' BACnet/IP Encode/Decode (subset)
        ' -------------------------------------------------------------------------

        Private Function NextInvokeId() As Byte
            SyncLock _sync
                _invokeId = CByte((_invokeId + 1) And &HFF)
                If _invokeId = 0 Then _invokeId = 1
                Return _invokeId
            End SyncLock
        End Function

        Private Function SendReadProperty(objType As BacnetObjectTypes, instance As UInteger, propId As BacnetPropertyIds, ByRef invoke As Byte, ByRef response As Byte()) As Boolean
            Dim udpLocal As UdpClient = Nothing
            Dim remoteLocal As IPEndPoint = Nothing
            SyncLock _sync
                udpLocal = _udp
                remoteLocal = _remote
            End SyncLock
            If udpLocal Is Nothing OrElse remoteLocal Is Nothing Then Return False

            invoke = NextInvokeId()
            Dim apdu As Byte() = BuildReadPropertyApdu(invoke, objType, instance, CUInt(propId))
            Dim pkt As Byte() = WrapBacnetIp(apdu)

            Try
                udpLocal.Send(pkt, pkt.Length, remoteLocal)
                Dim ep As New IPEndPoint(IPAddress.Any, 0)
                response = udpLocal.Receive(ep)
                Return response IsNot Nothing AndAlso response.Length > 0
            Catch
                response = Nothing
                Return False
            End Try
        End Function

        Private Function SendWritePropertyBinaryOutput(instance As UInteger, state As Boolean, ByRef invoke As Byte, ByRef response As Byte()) As Boolean
            Dim udpLocal As UdpClient = Nothing
            Dim remoteLocal As IPEndPoint = Nothing
            SyncLock _sync
                udpLocal = _udp
                remoteLocal = _remote
            End SyncLock
            If udpLocal Is Nothing OrElse remoteLocal Is Nothing Then Return False

            invoke = NextInvokeId()
            Dim apdu As Byte() = BuildWritePropertyBinaryOutputApdu(invoke, instance, state)
            Dim pkt As Byte() = WrapBacnetIp(apdu)

            Try
                udpLocal.Send(pkt, pkt.Length, remoteLocal)
                Dim ep As New IPEndPoint(IPAddress.Any, 0)
                response = udpLocal.Receive(ep)
                Return response IsNot Nothing AndAlso response.Length > 0
            Catch
                response = Nothing
                Return False
            End Try
        End Function

        Private Shared Function WrapBacnetIp(apdu As Byte()) As Byte()
            Return WrapBacnetIpUnicast(apdu)
        End Function

        Private Shared Function WrapBacnetIpUnicast(apdu As Byte()) As Byte()
            ' BVLC (4) + NPDU (2) + APDU
            Dim npdu As Byte() = New Byte() {&H1, &H4} ' Version=1, Control=Expecting reply
            Dim totalLen As Integer = 4 + npdu.Length + apdu.Length
            Dim buf(totalLen - 1) As Byte

            buf(0) = &H81 ' BVLC type
            buf(1) = &HA ' Original-Unicast-NPDU
            buf(2) = CByte((totalLen >> 8) And &HFF)
            buf(3) = CByte(totalLen And &HFF)
            Buffer.BlockCopy(npdu, 0, buf, 4, npdu.Length)
            Buffer.BlockCopy(apdu, 0, buf, 4 + npdu.Length, apdu.Length)
            Return buf
        End Function

        Private Shared Function WrapBacnetIpBroadcast(apdu As Byte()) As Byte()
            ' BVLC Original-Broadcast-NPDU (0x0B)
            Dim npdu As Byte() = New Byte() {&H1, &H0} ' Version=1, Control=0
            Dim totalLen As Integer = 4 + npdu.Length + apdu.Length
            Dim buf(totalLen - 1) As Byte

            buf(0) = &H81
            buf(1) = &HB
            buf(2) = CByte((totalLen >> 8) And &HFF)
            buf(3) = CByte(totalLen And &HFF)
            Buffer.BlockCopy(npdu, 0, buf, 4, npdu.Length)
            Buffer.BlockCopy(apdu, 0, buf, 4 + npdu.Length, apdu.Length)
            Return buf
        End Function

        Private Shared Function BuildWhoIsApdu() As Byte()
            ' Unconfirmed Request, Service Choice = Who-Is (8)
            Return New Byte() {&H10, &H8}
        End Function

        Private Shared Function BuildBvlcRegisterForeignDevicePacket(ttlSeconds As Integer) As Byte()
            If ttlSeconds < 10 Then ttlSeconds = 10
            If ttlSeconds > 3600 Then ttlSeconds = 3600
            Dim totalLen As Integer = 6
            Dim buf(totalLen - 1) As Byte
            buf(0) = &H81
            buf(1) = &H5 ' Register-Foreign-Device
            buf(2) = 0
            buf(3) = CByte(totalLen)
            buf(4) = CByte((ttlSeconds >> 8) And &HFF)
            buf(5) = CByte(ttlSeconds And &HFF)
            Return buf
        End Function

        Private Shared Function ParseBvlcResultOk(pkt As Byte()) As Boolean
            ' BVLC-Result (0x00), result code 0x0000 = success
            If pkt Is Nothing OrElse pkt.Length < 6 Then Return False
            If pkt(0) <> &H81 OrElse pkt(1) <> &H0 Then Return False
            Dim code As UShort = CUShort((pkt(4) << 8) Or pkt(5))
            Return code = 0US
        End Function

        Private Shared Function TryParseIAm(pkt As Byte(), ByRef deviceInstanceOut As UInteger) As Boolean
            deviceInstanceOut = 0UI
            If pkt Is Nothing OrElse pkt.Length < 10 Then Return False
            If pkt(0) <> &H81 Then Return False

            ' Skip BVLC (4)
            Dim idx As Integer = 4
            ' Skip NPDU (at least 2 bytes: version + control)
            If idx + 2 > pkt.Length Then Return False
            idx += 2
            If idx + 2 > pkt.Length Then Return False

            ' APDU should be Unconfirmed Request (0x10), Service Choice I-Am (0)
            If pkt(idx) <> &H10 Then Return False
            If pkt(idx + 1) <> &H0 Then Return False
            idx += 2

            ' Find Application tag Object Identifier (tag 12, len 4 => 0xC4)
            For i As Integer = idx To Math.Min(pkt.Length - 5, idx + 20)
                If pkt(i) = &HC4 Then
                    Dim raw As UInteger = CUInt(pkt(i + 1)) << 24 Or CUInt(pkt(i + 2)) << 16 Or CUInt(pkt(i + 3)) << 8 Or CUInt(pkt(i + 4))
                    Dim objType As UInteger = (raw >> 22) And &H3FFUI
                    Dim inst As UInteger = raw And &H3FFFFFUI
                    If objType = CUInt(BacnetObjectTypes.OBJECT_DEVICE) Then
                        deviceInstanceOut = inst
                        Return True
                    End If
                End If
            Next

            Return False
        End Function

        Private Shared Function BuildReadPropertyApdu(invoke As Byte, objType As BacnetObjectTypes, instance As UInteger, propId As UInteger) As Byte()
            Dim body As New List(Of Byte)(32)

            ' Confirmed Request
            body.Add(&H0)      ' PDU type 0 (Confirmed Request)
            body.Add(&H5)      ' Max APDU (1476) + Max Segs (unspecified)
            body.Add(invoke)   ' Invoke ID
            body.Add(&HC)      ' Service choice: ReadProperty (12)

            ' Context 0: Object Identifier (4 bytes)
            body.AddRange(EncodeContextTag(0, 4))
            body.AddRange(EncodeObjectId(objType, instance))

            ' Context 1: Property Identifier (unsigned)
            Dim propBytes As Byte() = EncodeUnsigned(propId)
            body.AddRange(EncodeContextTag(1, propBytes.Length))
            body.AddRange(propBytes)

            Return body.ToArray()
        End Function

        Private Shared Function BuildWritePropertyBinaryOutputApdu(invoke As Byte, instance As UInteger, state As Boolean) As Byte()
            Dim body As New List(Of Byte)(40)

            ' Confirmed Request
            body.Add(&H0)      ' PDU type 0
            body.Add(&H5)      ' Max APDU
            body.Add(invoke)   ' Invoke ID
            body.Add(&HF)      ' Service choice: WriteProperty (15)

            ' Context 0: Object Identifier (Binary Output)
            body.AddRange(EncodeContextTag(0, 4))
            body.AddRange(EncodeObjectId(BacnetObjectTypes.OBJECT_BINARY_OUTPUT, instance))

            ' Context 1: Property Identifier (Present Value 85)
            Dim propBytes As Byte() = EncodeUnsigned(CUInt(BacnetPropertyIds.PROP_PRESENT_VALUE))
            body.AddRange(EncodeContextTag(1, propBytes.Length))
            body.AddRange(propBytes)

            ' Context 3: Opening tag (property value)
            body.Add(EncodeOpeningTag(3))

            ' Application tag: Enumerated (tag 9) with 1 byte value 0/1
            Dim v As Byte = If(state, CByte(1), CByte(0))
            body.Add(&H91) ' Tag=9, Len=1
            body.Add(v)

            ' Context 3: Closing tag
            body.Add(EncodeClosingTag(3))

            Return body.ToArray()
        End Function

        Private Shared Function EncodeObjectId(objType As BacnetObjectTypes, instance As UInteger) As Byte()
            ' 32-bit: (object_type << 22) | instance
            Dim raw As UInteger = (CUInt(objType) << 22) Or (instance And &H3FFFFFUI)
            Return EncodeUInt32BE(raw)
        End Function

        Private Shared Function EncodeUInt32BE(v As UInteger) As Byte()
            Return New Byte() {
                CByte((v >> 24) And &HFFUI),
                CByte((v >> 16) And &HFFUI),
                CByte((v >> 8) And &HFFUI),
                CByte(v And &HFFUI)
            }
        End Function

        Private Shared Function EncodeUnsigned(v As UInteger) As Byte()
            If v <= &HFFUI Then
                Return New Byte() {CByte(v And &HFFUI)}
            ElseIf v <= &HFFFFUI Then
                Return New Byte() {CByte((v >> 8) And &HFFUI), CByte(v And &HFFUI)}
            ElseIf v <= &HFFFFFFUI Then
                Return New Byte() {CByte((v >> 16) And &HFFUI), CByte((v >> 8) And &HFFUI), CByte(v And &HFFUI)}
            Else
                Return EncodeUInt32BE(v)
            End If
        End Function

        Private Shared Function EncodeContextTag(tagNumber As Integer, length As Integer) As IEnumerable(Of Byte)
            ' Context specific tag, tagNumber 0-14, length 0-4 supported here
            Dim b As Byte = CByte(((tagNumber And &HF) << 4) Or &H8 Or (length And &H7))
            Return New Byte() {b}
        End Function

        Private Shared Function EncodeOpeningTag(tagNumber As Integer) As Byte
            ' Context specific opening tag: length/value = 6
            Return CByte(((tagNumber And &HF) << 4) Or &HE)
        End Function

        Private Shared Function EncodeClosingTag(tagNumber As Integer) As Byte
            ' Context specific closing tag: length/value = 7
            Return CByte(((tagNumber And &HF) << 4) Or &HF)
        End Function

        Private Shared Function TryParseSimpleAck(pkt As Byte(), invoke As Byte, expectedServiceChoice As Byte) As Boolean
            Dim apduOffset As Integer
            If Not TryGetApduOffset(pkt, apduOffset) Then Return False

            If apduOffset + 2 >= pkt.Length Then Return False
            Dim pduTypeNibble As Byte = CByte(pkt(apduOffset) And &HF0)
            If pduTypeNibble <> &H20 Then Return False ' Simple ACK
            If pkt(apduOffset + 1) <> invoke Then Return False
            If pkt(apduOffset + 2) <> expectedServiceChoice Then Return False
            Return True
        End Function

        Private Shared Function TryParseReadPropertyAck(pkt As Byte(), invoke As Byte, ByRef outValue As Object) As Boolean
            outValue = Nothing
            Dim apduOffset As Integer
            If Not TryGetApduOffset(pkt, apduOffset) Then Return False

            If apduOffset + 2 >= pkt.Length Then Return False
            Dim pduTypeNibble As Byte = CByte(pkt(apduOffset) And &HF0)
            If pduTypeNibble <> &H30 Then Return False ' Complex ACK
            If pkt(apduOffset + 1) <> invoke Then Return False
            If pkt(apduOffset + 2) <> &HC Then Return False ' ReadProperty ACK

            ' Find Opening Tag 3 (0x3E), then parse first application tag after it
            Dim i As Integer = apduOffset + 3
            Dim openTag As Byte = &H3E
            While i < pkt.Length AndAlso pkt(i) <> openTag
                i += 1
            End While
            If i >= pkt.Length - 1 Then Return False
            i += 1

            ' Skip any context tags until we hit an application tag (context bit=0)
            While i < pkt.Length
                Dim b As Byte = pkt(i)
                Dim isContext As Boolean = (b And &H8) <> 0
                Dim lenVal As Integer = b And &H7
                Dim tagNo As Integer = (b >> 4) And &HF

                If Not isContext Then
                    ' Application tag
                    Return TryParseApplicationValue(pkt, i, outValue)
                End If

                ' Context tag - opening/closing are lenVal 6/7, otherwise skip value bytes
                If lenVal = 6 OrElse lenVal = 7 Then
                    i += 1
                Else
                    i += 1 + lenVal
                End If
            End While

            Return False
        End Function

        Private Shared Function TryParseApplicationValue(buf As Byte(), ByVal idx As Integer, ByRef outValue As Object) As Boolean
            outValue = Nothing
            If idx >= buf.Length Then Return False
            Dim b0 As Byte = buf(idx)
            Dim tagNo As Integer = (b0 >> 4) And &HF
            Dim lenVal As Integer = b0 And &H7

            ' Extended length not implemented (rare for our use-case)
            If lenVal = 5 Then
                If idx + 1 >= buf.Length Then Return False
                lenVal = buf(idx + 1)
                idx += 2
            Else
                idx += 1
            End If

            Select Case tagNo
                Case 1 ' Boolean (lenVal is the value)
                    outValue = (lenVal <> 0)
                    Return True

                Case 4 ' Real (4 bytes IEEE 754)
                    If lenVal <> 4 OrElse idx + 3 >= buf.Length Then Return False
                    Dim raw As UInteger = CUInt(buf(idx)) << 24 Or CUInt(buf(idx + 1)) << 16 Or CUInt(buf(idx + 2)) << 8 Or CUInt(buf(idx + 3))
                    ' Convert integer value to little-endian byte sequence for BitConverter.ToSingle
                    Dim bytesLE As Byte() = BitConverter.GetBytes(raw)
                    outValue = BitConverter.ToSingle(bytesLE, 0)
                    Return True

                Case 7 ' CharacterString
                    If lenVal < 1 OrElse idx + lenVal - 1 >= buf.Length Then Return False
                    Dim charset As Byte = buf(idx)
                    Dim strBytesLen As Integer = lenVal - 1
                    Dim s As String
                    If strBytesLen <= 0 Then
                        s = ""
                    Else
                        Dim sb As Byte() = New Byte(strBytesLen - 1) {}
                        Buffer.BlockCopy(buf, idx + 1, sb, 0, strBytesLen)
                        ' charset 0 = ANSI X3.4 / ASCII
                        s = Encoding.ASCII.GetString(sb)
                    End If
                    outValue = s
                    Return True

                Case 9 ' Enumerated
                    If lenVal < 1 OrElse idx + lenVal - 1 >= buf.Length Then Return False
                    Dim v As UInteger = 0UI
                    For j As Integer = 0 To lenVal - 1
                        v = (v << 8) Or buf(idx + j)
                    Next
                    outValue = v
                    Return True

                Case Else
                    ' Unknown tag type -> raw bytes
                    If lenVal < 0 OrElse idx + lenVal - 1 >= buf.Length Then Return False
                    Dim bb As Byte() = New Byte(Math.Max(0, lenVal - 1)) {}
                    If lenVal > 0 Then Buffer.BlockCopy(buf, idx, bb, 0, lenVal)
                    outValue = bb
                    Return True
            End Select
        End Function

        Private Shared Function TryGetApduOffset(pkt As Byte(), ByRef apduOffset As Integer) As Boolean
            apduOffset = -1
            If pkt Is Nothing OrElse pkt.Length < 6 Then Return False

            ' BVLC header
            If pkt(0) <> &H81 Then Return False

            Dim idx As Integer = 4
            If idx + 1 >= pkt.Length Then Return False

            ' NPDU
            Dim version As Byte = pkt(idx)
            If version <> &H1 Then Return False
            Dim control As Byte = pkt(idx + 1)
            idx += 2

            ' Destination present?
            If (control And &H20) <> 0 Then
                If idx + 2 >= pkt.Length Then Return False
                idx += 2 ' DNET
                Dim dlen As Integer = pkt(idx)
                idx += 1
                idx += dlen ' DADR
                idx += 1 ' Hop Count
            End If

            ' Source present?
            If (control And &H8) <> 0 Then
                If idx + 2 >= pkt.Length Then Return False
                idx += 2 ' SNET
                Dim slen As Integer = pkt(idx)
                idx += 1
                idx += slen ' SADR
            End If

            ' Network layer message?
            If (control And &H80) <> 0 Then
                ' Not supported
                Return False
            End If

            If idx >= pkt.Length Then Return False
            apduOffset = idx
            Return True
        End Function

        ' -------------------- Phase-1: ReadPropertyMultiple (RPM) support --------------------
        Private Structure RpmAccessSpec
            Public ObjType As BacnetObjectTypes
            Public Instance As UInteger
            Public Properties As BacnetPropertyIds()
        End Structure

        ''' <summary>
        ''' Reads all BI/BO/AI values using BACnet ReadPropertyMultiple (RPM).
        ''' This reduces UDP packet count and improves stability under continuous refresh.
        ''' </summary>
        Public Function TryReadSnapshotRPM(ByRef di() As Boolean, ByRef doo() As Boolean, ByRef ai() As Double) As Boolean
            If di Is Nothing OrElse di.Length < 16 Then ReDim di(15)
            If doo Is Nothing OrElse doo.Length < 16 Then ReDim doo(15)
            If ai Is Nothing OrElse ai.Length < 9 Then ReDim ai(8)

            Dim specs As New List(Of RpmAccessSpec)()

            ' BI 1..16 Present_Value
            For i As Integer = 1 To 16
                specs.Add(New RpmAccessSpec With {
                    .ObjType = BacnetObjectTypes.OBJECT_BINARY_INPUT,
                    .Instance = CUInt(i),
                    .Properties = New BacnetPropertyIds() {BacnetPropertyIds.PROP_PRESENT_VALUE}
                })
            Next

            ' BO 1..16 Present_Value
            For i As Integer = 1 To 16
                specs.Add(New RpmAccessSpec With {
                    .ObjType = BacnetObjectTypes.OBJECT_BINARY_OUTPUT,
                    .Instance = CUInt(i),
                    .Properties = New BacnetPropertyIds() {BacnetPropertyIds.PROP_PRESENT_VALUE}
                })
            Next

            ' AI 1..4 Present_Value (voltage inputs)
            For i As Integer = 1 To 4
                specs.Add(New RpmAccessSpec With {
                    .ObjType = BacnetObjectTypes.OBJECT_ANALOG_INPUT,
                    .Instance = CUInt(i),
                    .Properties = New BacnetPropertyIds() {BacnetPropertyIds.PROP_PRESENT_VALUE}
                })
            Next

            ' AI 101..105 Present_Value (sensors)
            For i As Integer = 101 To 105
                specs.Add(New RpmAccessSpec With {
                    .ObjType = BacnetObjectTypes.OBJECT_ANALOG_INPUT,
                    .Instance = CUInt(i),
                    .Properties = New BacnetPropertyIds() {BacnetPropertyIds.PROP_PRESENT_VALUE}
                })
            Next

            Dim okAny As Boolean = False
            Const BATCH_SIZE As Integer = 8

            Dim start As Integer = 0
            While start < specs.Count
                Dim count As Integer = Math.Min(BATCH_SIZE, specs.Count - start)
                Dim batch As List(Of RpmAccessSpec) = specs.GetRange(start, count)

                Dim invoke As Byte = 0
                Dim resp As Byte() = Nothing
                If Not SendReadPropertyMultiple(batch, invoke, resp) OrElse resp Is Nothing Then
                    start += count
                    Continue While
                End If

                Dim vals As Dictionary(Of String, Object) = Nothing
                If Not TryParseReadPropertyMultipleAck(resp, invoke, vals) OrElse vals Is Nothing Then
                    start += count
                    Continue While
                End If

                ' Apply values to arrays
                For Each s In batch
                    Dim key As String = MakeKey(s.ObjType, s.Instance, BacnetPropertyIds.PROP_PRESENT_VALUE)
                    If Not vals.ContainsKey(key) Then Continue For
                    Dim v As Object = vals(key)

                    If s.ObjType = BacnetObjectTypes.OBJECT_BINARY_INPUT Then
                        Dim idx As Integer = CInt(s.Instance) - 1
                        If idx >= 0 AndAlso idx < 16 Then
                            di(idx) = ToBool(v)
                            okAny = True
                        End If

                    ElseIf s.ObjType = BacnetObjectTypes.OBJECT_BINARY_OUTPUT Then
                        Dim idx As Integer = CInt(s.Instance) - 1
                        If idx >= 0 AndAlso idx < 16 Then
                            doo(idx) = ToBool(v)
                            okAny = True
                        End If

                    ElseIf s.ObjType = BacnetObjectTypes.OBJECT_ANALOG_INPUT Then
                        If s.Instance >= 1UI AndAlso s.Instance <= 4UI Then
                            ai(CInt(s.Instance) - 1) = ToDoubleSafe(v)
                            okAny = True
                        ElseIf s.Instance >= 101UI AndAlso s.Instance <= 105UI Then
                            ai(4 + (CInt(s.Instance) - 101)) = ToDoubleSafe(v)
                            okAny = True
                        End If
                    End If
                Next

                start += count
            End While

            Return okAny
        End Function

        ''' <summary>
        ''' Reads all static Device/Network properties in one RPM request.
        ''' Returns a dictionary of BacnetPropertyIds -> String values.
        ''' </summary>
        Public Function TryReadDeviceInfoRPM(ByRef outInfo As Dictionary(Of BacnetPropertyIds, String)) As Boolean
            outInfo = New Dictionary(Of BacnetPropertyIds, String)()

            Dim devSpec As New RpmAccessSpec With {
                .ObjType = BacnetObjectTypes.OBJECT_DEVICE,
                .Instance = _deviceInstance,
                .Properties = New BacnetPropertyIds() {
                    BacnetPropertyIds.PROP_OBJECT_NAME,
                    BacnetPropertyIds.PROP_DESCRIPTION,
                    BacnetPropertyIds.PROP_LOCATION,
                    BacnetPropertyIds.PROP_VENDOR_NAME,
                    BacnetPropertyIds.PROP_MODEL_NAME,
                    BacnetPropertyIds.PROP_FIRMWARE_REVISION,
                    BacnetPropertyIds.PROP_SERIAL_NUMBER,
                    BacnetPropertyIds.PROP_MESA_MAC_ADDRESS,
                    BacnetPropertyIds.PROP_MESA_HARDWARE_VER,
                    BacnetPropertyIds.PROP_MESA_YEAR_DEV,
                    BacnetPropertyIds.PROP_MESA_SUBNET_MASK,
                    BacnetPropertyIds.PROP_MESA_GATEWAY,
                    BacnetPropertyIds.PROP_MESA_DNS1,
                    BacnetPropertyIds.PROP_MESA_AP_SSID,
                    BacnetPropertyIds.PROP_MESA_AP_PASSWORD,
                    BacnetPropertyIds.PROP_MESA_AP_IP
                }
            }

            Dim invoke As Byte = 0
            Dim resp As Byte() = Nothing
            If Not SendReadPropertyMultiple(New List(Of RpmAccessSpec) From {devSpec}, invoke, resp) OrElse resp Is Nothing Then Return False

            Dim vals As Dictionary(Of String, Object) = Nothing
            If Not TryParseReadPropertyMultipleAck(resp, invoke, vals) OrElse vals Is Nothing Then Return False

            For Each p In devSpec.Properties
                Dim key As String = MakeKey(devSpec.ObjType, devSpec.Instance, p)
                If vals.ContainsKey(key) Then
                    outInfo(p) = Convert.ToString(vals(key), Globalization.CultureInfo.InvariantCulture)
                End If
            Next

            Return outInfo.Count > 0
        End Function

        Private Shared Function MakeKey(t As BacnetObjectTypes, inst As UInteger, prop As BacnetPropertyIds) As String
            Return CInt(t).ToString() & ":" & inst.ToString() & ":" & CUInt(prop).ToString()
        End Function

        Private Shared Function ToDoubleSafe(v As Object) As Double
            If v Is Nothing Then Return Double.NaN
            Try
                If TypeOf v Is Double Then Return CDbl(v)
                If TypeOf v Is Single Then Return CDbl(CSng(v))
                If TypeOf v Is Integer Then Return CDbl(CInt(v))
                If TypeOf v Is UInteger Then Return CDbl(CUInt(v))
                If TypeOf v Is Long Then Return CDbl(CLng(v))
                If TypeOf v Is ULong Then Return CDbl(CULng(v))
                Dim s As String = Convert.ToString(v, Globalization.CultureInfo.InvariantCulture)
                Dim d As Double
                If Double.TryParse(s, Globalization.NumberStyles.Any, Globalization.CultureInfo.InvariantCulture, d) Then Return d
            Catch
            End Try
            Return Double.NaN
        End Function

        Private Function SendReadPropertyMultiple(specs As List(Of RpmAccessSpec), ByRef invoke As Byte, ByRef response As Byte()) As Boolean
            Dim udpLocal As UdpClient = Nothing
            Dim remoteLocal As IPEndPoint = Nothing
            SyncLock _sync
                udpLocal = _udp
                remoteLocal = _remote
            End SyncLock
            If udpLocal Is Nothing OrElse remoteLocal Is Nothing Then Return False

            invoke = NextInvokeId()
            Dim apdu As Byte() = BuildReadPropertyMultipleApdu(invoke, specs)
            Dim pkt As Byte() = WrapBacnetIp(apdu)

            Try
                Dim origTimeout As Integer = udpLocal.Client.ReceiveTimeout
                udpLocal.Client.ReceiveTimeout = _timeoutMs

                udpLocal.Send(pkt, pkt.Length, remoteLocal)

                Dim repFrom As IPEndPoint = Nothing
                response = udpLocal.Receive(repFrom)

                udpLocal.Client.ReceiveTimeout = origTimeout
                Return response IsNot Nothing AndAlso response.Length > 0
            Catch
                response = Nothing
                Return False
            End Try
        End Function

        Private Shared Function BuildReadPropertyMultipleApdu(invoke As Byte, specs As List(Of RpmAccessSpec)) As Byte()
            ' APDU only (BVLL/NPDU added by WrapBacnetIp)
            Dim body As New List(Of Byte)()

            ' Confirmed Service Request
            body.Add(&H0) ' PDU type=0 (confirmed), no segmentation
            body.Add(&H5) ' Max segs/max APDU (safe default)
            body.Add(invoke)
            body.Add(&HE) ' service choice ReadPropertyMultiple

            For Each s In specs
                ' Object Identifier [0] (context tag 0, length 4)
                Dim rawObjId As UInteger = (CUInt(s.ObjType) << 22) Or (s.Instance And &H3FFFFFUI)
                body.AddRange(EncodeContextTag(0, 4))
                body.AddRange(EncodeUInt32BE(rawObjId))

                ' Property references list [1]
                body.Add(EncodeOpeningTag(1))
                For Each p In s.Properties
                    Dim propBytes As Byte() = EncodeUnsigned(CUInt(p))
                    body.AddRange(EncodeContextTag(0, propBytes.Length))
                    body.AddRange(propBytes)
                Next
                body.Add(EncodeClosingTag(1))
            Next

            Return body.ToArray()
        End Function

        Private Shared Function TryParseReadPropertyMultipleAck(pkt As Byte(), invoke As Byte, ByRef values As Dictionary(Of String, Object)) As Boolean
            values = New Dictionary(Of String, Object)()

            Dim apduOffset As Integer
            If Not TryGetApduOffset(pkt, apduOffset) Then Return False
            If apduOffset + 2 >= pkt.Length Then Return False

            Dim pduTypeNibble As Byte = CByte(pkt(apduOffset) And &HF0)
            If pduTypeNibble <> &H30 Then Return False ' Complex ACK
            If pkt(apduOffset + 1) <> invoke Then Return False
            If pkt(apduOffset + 2) <> &HE Then Return False ' RPM ACK

            Dim i As Integer = apduOffset + 3

            While i < pkt.Length
                ' Context object identifier tag 0 length 4 -> 0x0C
                If pkt(i) <> &HC Then Exit While
                If i + 5 >= pkt.Length Then Exit While

                Dim rawObjId As UInteger = ReadUInt32BE(pkt, i + 1)
                Dim objType As BacnetObjectTypes
                Dim inst As UInteger
                DecodeObjectId(rawObjId, objType, inst)
                i += 5

                ' Opening tag 1 -> 0x1E
                If i >= pkt.Length OrElse pkt(i) <> &H1E Then Exit While
                i += 1

                While i < pkt.Length AndAlso pkt(i) <> &H1F
                    ' Property identifier context tag 2
                    Dim hdr As Byte = pkt(i)
                    Dim tagNum As Integer = (hdr >> 4) And &HF
                    Dim isCtx As Boolean = (hdr And &H8) <> 0
                    Dim len As Integer = hdr And &H7
                    If Not isCtx OrElse tagNum <> 2 Then Exit While
                    i += 1
                    If i + len > pkt.Length Then Exit While

                    Dim propId As UInteger = 0UI
                    For k As Integer = 0 To len - 1
                        propId = (propId << 8) Or pkt(i + k)
                    Next
                    i += len

                    ' Opening tag 4 -> 0x4E
                    If i >= pkt.Length OrElse pkt(i) <> &H4E Then Exit While
                    i += 1

                    Dim v As Object = Nothing
                    Dim newIdx As Integer = i
                    If Not TryParseApplicationValue(pkt, i, v, newIdx) Then
                        v = Nothing
                    End If
                    i = newIdx

                    ' Closing tag 4 -> 0x4F
                    If i < pkt.Length AndAlso pkt(i) = &H4F Then
                        i += 1
                    Else
                        Exit While
                    End If

                    Dim key As String = CInt(objType).ToString() & ":" & inst.ToString() & ":" & propId.ToString()
                    values(key) = v
                End While

                ' Closing tag 1 -> 0x1F
                If i < pkt.Length AndAlso pkt(i) = &H1F Then i += 1
            End While

            Return values.Count > 0
        End Function

        Private Shared Function TryParseApplicationValue(pkt As Byte(), startIdx As Integer, ByRef outVal As Object, ByRef nextIdx As Integer) As Boolean
            outVal = Nothing
            nextIdx = startIdx
            If startIdx >= pkt.Length Then Return False

            Dim tag As Byte = pkt(startIdx)
            Dim tagNum As Integer = (tag >> 4) And &HF
            Dim len As Integer = tag And &H7

            ' Application tags are class=0 (bit3 = 0)
            If (tag And &H8) <> 0 Then Return False

            nextIdx = startIdx + 1

            Select Case tagNum
                Case 1 ' Boolean (length/value carries boolean)
                    outVal = (len <> 0)
                    Return True

                Case 2 ' Unsigned int
                    If nextIdx + len > pkt.Length Then Return False
                    Dim u As UInteger = 0UI
                    For i As Integer = 0 To len - 1
                        u = (u << 8) Or pkt(nextIdx + i)
                    Next
                    outVal = u
                    nextIdx += len
                    Return True

                Case 4 ' Real (4 bytes)
                    If len <> 4 OrElse nextIdx + 4 > pkt.Length Then Return False
                    Dim b(3) As Byte
                    Array.Copy(pkt, nextIdx, b, 0, 4)
                    If BitConverter.IsLittleEndian Then Array.Reverse(b)
                    outVal = BitConverter.ToSingle(b, 0)
                    nextIdx += 4
                    Return True

                Case 7 ' CharacterString
                    If nextIdx + len > pkt.Length Then Return False
                    If len < 1 Then
                        outVal = ""
                        Return True
                    End If
                    Dim strLen As Integer = len - 1
                    Dim s As String = Encoding.UTF8.GetString(pkt, nextIdx + 1, strLen)
                    outVal = s
                    nextIdx += len
                    Return True

                Case Else
                    Return False
            End Select
        End Function

        Private Shared Function ReadUInt32BE(buf As Byte(), offset As Integer) As UInteger
            If offset + 3 >= buf.Length Then Return 0UI
            Return (CUInt(buf(offset)) << 24) Or (CUInt(buf(offset + 1)) << 16) Or (CUInt(buf(offset + 2)) << 8) Or CUInt(buf(offset + 3))
        End Function

        Private Shared Sub DecodeObjectId(raw As UInteger, ByRef objType As BacnetObjectTypes, ByRef instance As UInteger)
            objType = CType((raw >> 22) And &H3FFUI, BacnetObjectTypes)
            instance = raw And &H3FFFFFUI
        End Sub

    End Class

End Namespace