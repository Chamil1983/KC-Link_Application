KC868 Modbus Master (VB.NET, .NET Framework 4.8)

Connect
- Wire USB-RS485 adapter to KC868 RS485 A/B; sharing GND is recommended.
- Defaults: Slave ID 1, 38400 baud, 8N1.
- Select COM port and click CONNECT.

Features
- Auto Poll with comm + heartbeat indicator.
- LEDs for digital inputs; checkboxes for digital outputs.
- Register Map grid (R/W aware) with write.
- Manual register read/write tool and Export Map to CSV.
