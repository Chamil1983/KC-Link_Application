/**
 * @file
 * @brief Send Read Property Multiple request.
 * @author Steve Karg <skarg@users.sourceforge.net>
 * @date 2008
 * @copyright SPDX-License-Identifier: MIT
 */
#include <stddef.h>
#include <stdint.h>
#include <string.h>
/* BACnet Stack defines - first */
#include "bacnet/bacdef.h"
/* BACnet Stack API */
#include "bacnet/bacdcode.h"
#include "bacnet/npdu.h"
#include "bacnet/apdu.h"
#include "bacnet/dcc.h"
#include "bacnet/rpm.h"
/* some demo stuff needed */
#include "bacnet/basic/object/device.h"
#include "bacnet/datalink/datalink.h"
#include "bacnet/basic/binding/address.h"
#include "bacnet/basic/tsm/tsm.h"
#include "bacnet/basic/services.h"
#include "bacnet/basic/sys/debug.h"

/**
 * @brief Sends a Read Property Multiple request.
 * @ingroup BIBB-DS-RPM-A
 * @param dest [in] BACNET_ADDRESS of the destination device
 * @param max_apdu [in]
 * @param pdu [out] Buffer to build the outgoing message into
 * @param max_pdu [in] Length of the pdu buffer.
 * @param device_id [in] ID of the destination device
 * @param read_access_data [in] Ptr to structure with the linked list of
 *        properties to be read.
 * @return invoke id of outgoing message, or 0 if device is not bound or no tsm
 * available
 */
BACNET_STACK_EXPORT
uint8_t Send_Read_Property_Multiple_Request_Address(
    BACNET_ADDRESS *dest,
    uint16_t max_apdu,
    uint8_t *pdu,
    size_t max_pdu,
    BACNET_READ_ACCESS_DATA *read_access_data)
{
    BACNET_ADDRESS my_address;
    uint8_t invoke_id = 0;
    int len = 0;
    int pdu_len = 0;
    int bytes_sent = 0;
    BACNET_NPDU_DATA npdu_data;

    if (!dcc_communication_enabled()) {
        return 0;
    }
    invoke_id = tsm_next_free_invokeID();
    if (invoke_id) {
        /* encode the NPDU portion of the packet */
        datalink_get_my_address(&my_address);
        npdu_encode_npdu_data(&npdu_data, true, MESSAGE_PRIORITY_NORMAL);
        pdu_len = npdu_encode_pdu(&pdu[0], dest, &my_address, &npdu_data);
        /* encode the APDU portion of the packet */
        len = rpm_encode_apdu(
            &pdu[pdu_len], max_pdu - pdu_len, invoke_id, read_access_data);
        if (len <= 0) {
            return 0;
        }
        pdu_len += len;
        /* is it small enough for the destination to receive?
           note: if there is a bottleneck router in between
           us and the destination, we won't know unless
           we have a way to check for that and update the
           max_apdu in the address binding table. */
        if ((unsigned)pdu_len < max_apdu) {
            tsm_set_confirmed_unsegmented_transaction(
                invoke_id, dest, &npdu_data, &pdu[0], (uint16_t)pdu_len);
            bytes_sent = datalink_send_pdu(dest, &npdu_data, &pdu[0], pdu_len);
            if (bytes_sent <= 0) {
                debug_perror("Failed to Send ReadPropertyMultiple Request");
            }
        } else {
            tsm_free_invoke_id(invoke_id);
            invoke_id = 0;
            debug_fprintf(
                stderr,
                "Failed to Send ReadPropertyMultiple Request "
                "(exceeds destination maximum APDU)!\n");
        }
    }

    return invoke_id;
}

/**
 * @brief Sends a Read Property Multiple request.
 * @ingroup BIBB-DS-RPM-A
 * @param pdu [out] Buffer to build the outgoing message into
 * @param max_pdu [in] Length of the pdu buffer.
 * @param device_id [in] ID of the destination device
 * @param read_access_data [in] Ptr to structure with the linked list of
 *        properties to be read.
 * @return invoke id of outgoing message, or 0 if device is not bound or no tsm
 * available
 */
uint8_t Send_Read_Property_Multiple_Request(
    uint8_t *pdu,
    size_t max_pdu,
    uint32_t device_id, /* destination device */
    BACNET_READ_ACCESS_DATA *read_access_data)
{
    BACNET_ADDRESS dest = { 0 };
    unsigned max_apdu = 0;
    uint8_t invoke_id = 0;
    bool status = false;

    /* is the device bound? */
    status = address_get_by_device(device_id, &max_apdu, &dest);
    if (status) {
        invoke_id = Send_Read_Property_Multiple_Request_Address(
            &dest, max_apdu, pdu, max_pdu, read_access_data);
    }
    return invoke_id;
}
