#pragma once
#include "../FunctionPrototypes.h"

// Main application entrypoints (called by KC868_A16_Controller.ino)
void appSetup();
void appLoop();
