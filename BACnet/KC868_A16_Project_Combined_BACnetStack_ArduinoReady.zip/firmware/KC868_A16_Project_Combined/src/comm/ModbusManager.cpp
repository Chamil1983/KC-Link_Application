#include "ModbusManager.h"
#include "../FunctionPrototypes.h"

#include <ModbusRTU.h>
#include <WiFi.h>
#include <ETH.h>

namespace {

    // =====================
    // Register map sizes
    // =====================
    constexpr uint16_t HR_MAX = 700;   // Holding registers 0..699 (map uses up to 651)
    constexpr uint16_t IR_MAX = 200;   // Input registers 0..199 (map uses up to 114)
    constexpr uint16_t COIL_MAX = 32;  // Coils 0..31
    constexpr uint16_t ISTS_MAX = 32;  // Discrete inputs 0..31

    constexpr uint16_t APPLY_TOKEN = 0xA55A;
    constexpr uint16_t RESTART_TOKEN = 0xDEAD;
    constexpr uint16_t FACTORY_TOKEN = 0xBEEF;

    // =====================
    // Holding registers (4xxxx)
    // =====================
    // Section 1: Board Info (RO)
    constexpr uint16_t HR_BOARD_NAME_BASE = 0;   // 0..7  (ASCII 16)
    constexpr uint16_t HR_SERIAL_BASE = 8;   // 8..15 (ASCII 16)
    constexpr uint16_t HR_MANUFACTURER_BASE = 16;  // 16..27 (ASCII 24)
    constexpr uint16_t HR_FW_VER_BASE = 28;  // 28..35 (ASCII 16)
    constexpr uint16_t HR_HW_VER_BASE = 36;  // 36..43 (ASCII 16)
    constexpr uint16_t HR_YEAR = 44;  // uint16
    constexpr uint16_t HR_BOARD_MODEL_CODE = 45;  // uint16 (16)
    constexpr uint16_t HR_ETH_MAC_BASE = 46;  // 46..48 (6 bytes)
    constexpr uint16_t HR_WIFI_STA_MAC_BASE = 49;  // 49..51
    constexpr uint16_t HR_WIFI_AP_MAC_BASE = 52;  // 52..54

    // Section 2: Network Settings (RW)
    constexpr uint16_t HR_NET_DHCP_MODE = 100; // 0=Static, 1=DHCP
    constexpr uint16_t HR_NET_TCP_PORT = 101; // uint16
    constexpr uint16_t HR_NET_STATIC_IP_BASE = 102; // 102-103 (IPv4)
    constexpr uint16_t HR_NET_STATIC_SUB_BASE = 104; // 104-105
    constexpr uint16_t HR_NET_STATIC_GW_BASE = 106; // 106-107
    constexpr uint16_t HR_NET_STATIC_DNS1_BASE = 108; // 108-109
    constexpr uint16_t HR_NET_STATIC_DNS2_BASE = 110; // 110-111
    constexpr uint16_t HR_WIFI_AP_SSID_BASE = 112; // 112..143 (ASCII 64)
    constexpr uint16_t HR_WIFI_AP_PASS_BASE = 144; // 144..175 (ASCII 64)
    constexpr uint16_t HR_WIFI_STA_SSID_BASE = 176; // 176..207 (ASCII 64)
    constexpr uint16_t HR_WIFI_STA_PASS_BASE = 208; // 208..239 (ASCII 64)
    constexpr uint16_t HR_NET_APPLY = 240; // write 0xA55A => save + reboot

    // Section 3: Communication (Serial + Modbus) (RW)
    constexpr uint16_t HR_USB_BAUD_HI = 300; // 300-301 uint32
    constexpr uint16_t HR_USB_BAUD_LO = 301;
    constexpr uint16_t HR_USB_DATABITS = 302; // 7/8
    constexpr uint16_t HR_USB_PARITY = 303; // 0 N,1 O,2 E
    constexpr uint16_t HR_USB_STOPBITS = 304; // 1/2
    constexpr uint16_t HR_USB_COMPORT = 305; // informational

    constexpr uint16_t HR_MB_BAUD_HI = 310; // 310-311 uint32
    constexpr uint16_t HR_MB_BAUD_LO = 311;
    constexpr uint16_t HR_MB_DATABITS = 312;
    constexpr uint16_t HR_MB_PARITY = 313;
    constexpr uint16_t HR_MB_STOPBITS = 314;
    constexpr uint16_t HR_MB_SLAVE_ID = 315;
    constexpr uint16_t HR_MB_TIMEOUT_MS = 316; // store only
    constexpr uint16_t HR_MB_RETRY_COUNT = 317; // store only
    // Apply Modbus serial/slave settings without reboot
    constexpr uint16_t HR_MB_APPLY = 340; // write 0xA55A => save + re-init RS485/Modbus
    constexpr uint16_t HR_ACTIVE_PROTOCOL = 318; // 0=WiFi,1=ETH,2=USB,3=RS485
    constexpr uint16_t HR_PROTO_APPLY = 319; // write 0xA55A => save active protocol + reboot

    // Health/Heartbeat
    constexpr uint16_t HR_HEARTBEAT_WRITE = 360; // master writes incrementing

    // Section 4: Hardware control
    constexpr uint16_t HR_OUTPUTS_BITMASK = 400; // write sets 16 outputs
    constexpr uint16_t HR_OUTPUTS_APPLY = 401; // optional; write 0xA55A applies (we apply immediately)

    // RTC set
    constexpr uint16_t HR_RTC_SET_YEAR = 500;
    constexpr uint16_t HR_RTC_SET_MONTH = 501;
    constexpr uint16_t HR_RTC_SET_DAY = 502;
    constexpr uint16_t HR_RTC_SET_HOUR = 503;
    constexpr uint16_t HR_RTC_SET_MIN = 504;
    constexpr uint16_t HR_RTC_SET_SEC = 505;
    constexpr uint16_t HR_RTC_SET_DOW = 506;
    constexpr uint16_t HR_RTC_APPLY = 507; // write 0xA55A sets RTC

    // System commands
    constexpr uint16_t HR_SYS_REBOOT = 650; // write 0xDEAD
    constexpr uint16_t HR_SYS_FACTORY_RESET = 651; // write 0xBEEF

    // =====================
    // Input registers (3xxxx)
    // =====================
    constexpr uint16_t IR_STATUS_FLAGS = 0;
    constexpr uint16_t IR_UPTIME_HI = 1;
    constexpr uint16_t IR_UPTIME_LO = 2;
    constexpr uint16_t IR_LAST_ERROR_CODE = 3;
    constexpr uint16_t IR_CHANGE_COUNTER = 4;
    constexpr uint16_t IR_HEARTBEAT_ECHO = 5;
    constexpr uint16_t IR_HEARTBEAT_AGE_MS = 6;

    constexpr uint16_t IR_DI_BITMASK = 10;
    constexpr uint16_t IR_DO_BITMASK = 11;

    constexpr uint16_t IR_AI1_RAW = 20;
    constexpr uint16_t IR_AI1_MV = 21;
    constexpr uint16_t IR_AI2_RAW = 22;
    constexpr uint16_t IR_AI2_MV = 23;
    constexpr uint16_t IR_AI3_RAW = 24;
    constexpr uint16_t IR_AI3_MV = 25;
    constexpr uint16_t IR_AI4_RAW = 26;
    constexpr uint16_t IR_AI4_MV = 27;

    constexpr uint16_t IR_DHT1_TEMP_X10 = 30;
    constexpr uint16_t IR_DHT1_HUM_X10 = 31;
    constexpr uint16_t IR_DHT2_TEMP_X10 = 32;
    constexpr uint16_t IR_DHT2_HUM_X10 = 33;
    constexpr uint16_t IR_DS18_TEMP_X10 = 34;

    constexpr uint16_t IR_RTC_YEAR = 40;
    constexpr uint16_t IR_RTC_MONTH = 41;
    constexpr uint16_t IR_RTC_DAY = 42;
    constexpr uint16_t IR_RTC_HOUR = 43;
    constexpr uint16_t IR_RTC_MIN = 44;
    constexpr uint16_t IR_RTC_SEC = 45;
    constexpr uint16_t IR_RTC_DOW = 46;
    constexpr uint16_t IR_RTC_EPOCH_HI = 47;
    constexpr uint16_t IR_RTC_EPOCH_LO = 48;

    // Current network info
    constexpr uint16_t IR_NET_FLAGS = 100; // bit0=ETH link, bit1=ETH hasIP, bit2=WiFi STA conn, bit3=WiFi AP
    constexpr uint16_t IR_NET_CUR_TCP_PORT = 101;
    constexpr uint16_t IR_NET_CUR_IP_BASE = 102; // 102-103
    constexpr uint16_t IR_NET_CUR_SUB_BASE = 104; // 104-105
    constexpr uint16_t IR_NET_CUR_GW_BASE = 106; // 106-107
    constexpr uint16_t IR_NET_CUR_DNS1_BASE = 108; // 108-109
    constexpr uint16_t IR_NET_CUR_DNS2_BASE = 110; // 110-111
    constexpr uint16_t IR_WIFI_RSSI_DBM = 112; // signed int16
    constexpr uint16_t IR_ETH_LINK_SPEED = 113; // Mbps
    constexpr uint16_t IR_ETH_DUPLEX = 114; // 0 half, 1 full

    // =====================
    // Helpers
    // =====================
    static ModbusRTU mb;
    static bool enabled = false;

    static uint16_t hrShadow[HR_MAX] = { 0 };

    static uint32_t changeCounter = 0;
    static uint16_t heartbeatEcho = 0;
    static uint32_t heartbeatLastMs = 0;

    static uint16_t pack2(char a, char b) {
        return ((uint16_t)(uint8_t)a << 8) | (uint16_t)(uint8_t)b;
    }
    static void unpack2(uint16_t w, char& a, char& b) {
        a = (char)((w >> 8) & 0xFF);
        b = (char)(w & 0xFF);
    }

    static uint16_t ipWord(const IPAddress& ip, uint8_t idx) {
        if (idx == 0) return pack2((char)ip[0], (char)ip[1]);
        return pack2((char)ip[2], (char)ip[3]);
    }
    static IPAddress wordsToIP(uint16_t w0, uint16_t w1) {
        char a, b, c, d;
        unpack2(w0, a, b);
        unpack2(w1, c, d);
        return IPAddress((uint8_t)a, (uint8_t)b, (uint8_t)c, (uint8_t)d);
    }

    static uint16_t u32Hi(uint32_t v) { return (uint16_t)(v >> 16); }
    static uint16_t u32Lo(uint32_t v) { return (uint16_t)(v & 0xFFFF); }
    static uint32_t hiLoToU32(uint16_t hi, uint16_t lo) { return ((uint32_t)hi << 16) | (uint32_t)lo; }

    static String trimNullSpace(String s) {
        s.replace("\0", "");
        s.trim();
        return s;
    }

    static void writeStringToShadow(uint16_t base, uint16_t regs, const String& s) {
        for (uint16_t i = 0; i < regs; i++) {
            uint16_t charIndex = i * 2;
            char c1 = (charIndex < s.length()) ? s[charIndex] : 0;
            char c2 = (charIndex + 1 < s.length()) ? s[charIndex + 1] : 0;
            hrShadow[base + i] = pack2(c1, c2);
        }
    }

    static String readStringFromShadow(uint16_t base, uint16_t regs) {
        String out;
        out.reserve(regs * 2);
        for (uint16_t i = 0; i < regs; i++) {
            char a, b;
            unpack2(hrShadow[base + i], a, b);
            if (a) out += a;
            if (b) out += b;
        }
        return trimNullSpace(out);
    }

    static uint16_t readStringReg(const String& s, uint16_t base, uint16_t addr) {
        uint16_t idx = addr - base;
        uint16_t charIndex = idx * 2;
        char c1 = (charIndex < s.length()) ? s[charIndex] : 0;
        char c2 = (charIndex + 1 < s.length()) ? s[charIndex + 1] : 0;
        return pack2(c1, c2);
    }

    static bool parseMacToBytes(const String& macStr, uint8_t out[6]) {
        String s = macStr;
        s.replace(":", "");
        s.replace("-", "");
        s.toUpperCase();
        if (s.length() != 12) return false;
        for (int i = 0; i < 6; i++) {
            char hi = s[i * 2];
            char lo = s[i * 2 + 1];
            auto hexVal = [](char c) -> int {
                if (c >= '0' && c <= '9') return c - '0';
                if (c >= 'A' && c <= 'F') return 10 + (c - 'A');
                return 0;
            };
            out[i] = (uint8_t)((hexVal(hi) << 4) | hexVal(lo));
        }
        return true;
    }

    static void macRegsFromBytes(const uint8_t b[6], uint16_t regsOut[3]) {
        regsOut[0] = pack2((char)b[0], (char)b[1]);
        regsOut[1] = pack2((char)b[2], (char)b[3]);
        regsOut[2] = pack2((char)b[4], (char)b[5]);
    }

    // ModbusRTU library has had a couple of different TRegister layouts.
    // This helper extracts the register address in a version-tolerant way.
    template <typename T>
    static auto regAddrImpl(const T* reg, int) -> decltype(reg->address.address, uint16_t()) {
        return (uint16_t)reg->address.address;
    }
    template <typename T>
    static auto regAddrImpl(const T* reg, long) -> decltype(reg->address, uint16_t()) {
        return (uint16_t)reg->address;
    }
    static uint16_t regAddr(const TRegister* reg) {
        return regAddrImpl(reg, 0);
    }

    static uint16_t clampU16(uint32_t v, uint16_t minV, uint16_t maxV) {
        if (v < minV) return minV;
        if (v > maxV) return maxV;
        return (uint16_t)v;
    }

    static uint16_t statusFlags() {
        uint16_t f = 0;
        if (wifiClientMode && wifiConnected) f |= (1 << 0);
        if (apMode) f |= (1 << 1);
        if (ethConnected) f |= (1 << 2);
        if (ethConnected && ETH.localIP()[0] != 0) f |= (1 << 3);
        if (rtcInitialized) f |= (1 << 4);

        // Sensors OK flags (based on "configured")
        if (htSensorConfig[0].configured) f |= (1 << 5);
        if (htSensorConfig[1].configured) f |= (1 << 6);
        if (htSensorConfig[2].configured) f |= (1 << 7);
        return f;
    }

    static uint16_t netFlags() {
        uint16_t f = 0;
        if (ethConnected) f |= (1 << 0);
        if (ethConnected && ETH.localIP()[0] != 0) f |= (1 << 1);
        if (wifiClientMode && wifiConnected) f |= (1 << 2);
        if (apMode) f |= (1 << 3);
        return f;
    }

    static int16_t toX10Signed(float v) {
        if (isnan(v)) return (int16_t)0x8000;
        long x10 = lroundf(v * 10.0f);
        if (x10 < -32768) x10 = -32768;
        if (x10 > 32767) x10 = 32767;
        return (int16_t)x10;
    }

    static uint16_t analogMv(float volts) {
        long mv = lroundf(volts * 1000.0f);
        if (mv < 0) mv = 0;
        if (mv > 5000) mv = 5000;
        return (uint16_t)mv;
    }

    static void syncShadowFromGlobals() {
        // Network
        hrShadow[HR_NET_DHCP_MODE] = dhcpMode ? 1 : 0;
        hrShadow[HR_NET_TCP_PORT] = 80;

        hrShadow[HR_NET_STATIC_IP_BASE] = ipWord(ip, 0);
        hrShadow[HR_NET_STATIC_IP_BASE + 1] = ipWord(ip, 1);
        hrShadow[HR_NET_STATIC_SUB_BASE] = ipWord(subnet, 0);
        hrShadow[HR_NET_STATIC_SUB_BASE + 1] = ipWord(subnet, 1);
        hrShadow[HR_NET_STATIC_GW_BASE] = ipWord(gateway, 0);
        hrShadow[HR_NET_STATIC_GW_BASE + 1] = ipWord(gateway, 1);
        hrShadow[HR_NET_STATIC_DNS1_BASE] = ipWord(dns1, 0);
        hrShadow[HR_NET_STATIC_DNS1_BASE + 1] = ipWord(dns1, 1);
        hrShadow[HR_NET_STATIC_DNS2_BASE] = ipWord(dns2, 0);
        hrShadow[HR_NET_STATIC_DNS2_BASE + 1] = ipWord(dns2, 1);

        writeStringToShadow(HR_WIFI_AP_SSID_BASE, 32, apSSIDConfig);
        writeStringToShadow(HR_WIFI_AP_PASS_BASE, 32, apPasswordConfig);
        writeStringToShadow(HR_WIFI_STA_SSID_BASE, 32, wifiSSID);
        writeStringToShadow(HR_WIFI_STA_PASS_BASE, 32, wifiPassword);

        // USB comm
        uint32_t ubaud = (uint32_t)usbBaudRate;
        hrShadow[HR_USB_BAUD_HI] = u32Hi(ubaud);
        hrShadow[HR_USB_BAUD_LO] = u32Lo(ubaud);
        hrShadow[HR_USB_DATABITS] = (uint16_t)usbDataBits;
        hrShadow[HR_USB_PARITY] = (uint16_t)usbParity;
        hrShadow[HR_USB_STOPBITS] = (uint16_t)usbStopBits;
        hrShadow[HR_USB_COMPORT] = (uint16_t)usbComPort;

        // Modbus/RS485 comm
        uint32_t mbaud = (uint32_t)rs485BaudRate;
        hrShadow[HR_MB_BAUD_HI] = u32Hi(mbaud);
        hrShadow[HR_MB_BAUD_LO] = u32Lo(mbaud);
        hrShadow[HR_MB_DATABITS] = (uint16_t)rs485DataBits;
        hrShadow[HR_MB_PARITY] = (uint16_t)rs485Parity;
        hrShadow[HR_MB_STOPBITS] = (uint16_t)rs485StopBits;
        hrShadow[HR_MB_SLAVE_ID] = (uint16_t)rs485DeviceAddress;

        // Optional (store only)
        if (hrShadow[HR_MB_TIMEOUT_MS] == 0) hrShadow[HR_MB_TIMEOUT_MS] = 1000;
        if (hrShadow[HR_MB_RETRY_COUNT] == 0) hrShadow[HR_MB_RETRY_COUNT] = 3;

        // Active protocol
        uint16_t proto = 0;
        if (currentCommunicationProtocol == "wifi") proto = 0;
        else if (currentCommunicationProtocol == "ethernet") proto = 1;
        else if (currentCommunicationProtocol == "usb") proto = 2;
        else if (currentCommunicationProtocol == "rs485") proto = 3;
        hrShadow[HR_ACTIVE_PROTOCOL] = proto;

        // RTC defaults
        if (rtcInitialized) {
            DateTime now = rtc.now();
            hrShadow[HR_RTC_SET_YEAR] = (uint16_t)now.year();
            hrShadow[HR_RTC_SET_MONTH] = (uint16_t)now.month();
            hrShadow[HR_RTC_SET_DAY] = (uint16_t)now.day();
            hrShadow[HR_RTC_SET_HOUR] = (uint16_t)now.hour();
            hrShadow[HR_RTC_SET_MIN] = (uint16_t)now.minute();
            hrShadow[HR_RTC_SET_SEC] = (uint16_t)now.second();
            hrShadow[HR_RTC_SET_DOW] = (uint16_t)now.dayOfTheWeek();
        }
    }

    static void applyNetworkFromShadow() {
        dhcpMode = (hrShadow[HR_NET_DHCP_MODE] != 0);
        // Note: TCP port for web server is fixed at 80 in this firmware.

        ip = wordsToIP(hrShadow[HR_NET_STATIC_IP_BASE], hrShadow[HR_NET_STATIC_IP_BASE + 1]);
        subnet = wordsToIP(hrShadow[HR_NET_STATIC_SUB_BASE], hrShadow[HR_NET_STATIC_SUB_BASE + 1]);
        gateway = wordsToIP(hrShadow[HR_NET_STATIC_GW_BASE], hrShadow[HR_NET_STATIC_GW_BASE + 1]);
        dns1 = wordsToIP(hrShadow[HR_NET_STATIC_DNS1_BASE], hrShadow[HR_NET_STATIC_DNS1_BASE + 1]);
        dns2 = wordsToIP(hrShadow[HR_NET_STATIC_DNS2_BASE], hrShadow[HR_NET_STATIC_DNS2_BASE + 1]);

        apSSIDConfig = readStringFromShadow(HR_WIFI_AP_SSID_BASE, 32);
        apPasswordConfig = readStringFromShadow(HR_WIFI_AP_PASS_BASE, 32);
        wifiSSID = readStringFromShadow(HR_WIFI_STA_SSID_BASE, 32);
        wifiPassword = readStringFromShadow(HR_WIFI_STA_PASS_BASE, 32);

        // Persist
        saveAPCredentials(apSSIDConfig, apPasswordConfig);
        saveWiFiCredentials(wifiSSID, wifiPassword);
        saveNetworkSettings();
    }

    static void applyUsbFromShadow() {
        uint32_t baud = hiLoToU32(hrShadow[HR_USB_BAUD_HI], hrShadow[HR_USB_BAUD_LO]);
        if (baud < 1200) baud = 115200;
        usbBaudRate = (int)baud;
        usbDataBits = (int)clampU16(hrShadow[HR_USB_DATABITS], 7, 8);
        usbParity = (int)clampU16(hrShadow[HR_USB_PARITY], 0, 2);
        usbStopBits = (int)clampU16(hrShadow[HR_USB_STOPBITS], 1, 2);
        usbComPort = (int)hrShadow[HR_USB_COMPORT];
    }

    static void applyModbusFromShadow(bool reinitNow) {
        uint32_t baud = hiLoToU32(hrShadow[HR_MB_BAUD_HI], hrShadow[HR_MB_BAUD_LO]);
        if (baud < 1200) baud = 9600;

        rs485BaudRate = (int)baud;
        rs485DataBits = (int)clampU16(hrShadow[HR_MB_DATABITS], 7, 8);
        rs485Parity = (int)clampU16(hrShadow[HR_MB_PARITY], 0, 2);
        rs485StopBits = (int)clampU16(hrShadow[HR_MB_STOPBITS], 1, 2);

        int sid = (int)hrShadow[HR_MB_SLAVE_ID];
        if (sid < 1) sid = 1;
        if (sid > 247) sid = 247;
        rs485DeviceAddress = sid;

        // Ensure protocol set
        rs485Protocol = "Modbus RTU";
        currentCommunicationProtocol = "rs485";

        // Persist RS485 settings
        saveCommunicationConfig();

        if (reinitNow) {
            initRS485();
            // Re-config server address
            mb.server((uint8_t)rs485DeviceAddress);
        }
    }

    static void applyProtocolFromShadow() {
        uint16_t p = hrShadow[HR_ACTIVE_PROTOCOL];
        switch (p) {
        case 0: currentCommunicationProtocol = "wifi"; break;
        case 1: currentCommunicationProtocol = "ethernet"; break;
        case 2: currentCommunicationProtocol = "usb"; break;
        case 3: currentCommunicationProtocol = "rs485"; break;
        default: currentCommunicationProtocol = "wifi"; break;
        }

        // Persist and restart so the system cleanly switches
        saveCommunicationSettings();
    }

    static void setOutputsFromBitmask(uint16_t mask) {
        bool changed = false;
        for (int i = 0; i < 16; i++) {
            bool state = (mask & (1 << i)) != 0;
            if (outputStates[i] != state) {
                outputStates[i] = state;
                changed = true;
            }
        }
        if (changed) {
            writeOutputs();
            broadcastUpdate();
            changeCounter++;
        }
    }

    static void doAllOutputs(bool on) {
        bool changed = false;
        for (int i = 0; i < 16; i++) {
            if (outputStates[i] != on) {
                outputStates[i] = on;
                changed = true;
            }
        }
        if (changed) {
            writeOutputs();
            broadcastUpdate();
            changeCounter++;
        }
    }

    static void factoryReset() {
        // Minimal reset: reinitialize defaults, clear stored credentials and configs.
        initializeDefaultConfig();

        // Clear WiFi STA creds
        saveWiFiCredentials("", "");

        // Restore AP creds to compiled defaults
        saveAPCredentials(String(ap_ssid), String(ap_password));

        // Persist other configs
        saveConfiguration();
        saveNetworkSettings();
        saveCommunicationSettings();
        saveCommunicationConfig();

        restartRequired = true;
    }

    // =====================
    // Modbus callbacks
    // =====================

    // Holding registers
    static uint16_t cbHregGet(TRegister* reg, uint16_t) {
        uint16_t a = regAddr(reg);

        // Board Info RO
        if (a >= HR_BOARD_NAME_BASE && a < HR_BOARD_NAME_BASE + 8) {
            return readStringReg(String("KC868-A16"), HR_BOARD_NAME_BASE, a);
        }
        if (a >= HR_SERIAL_BASE && a < HR_SERIAL_BASE + 8) {
            // Serial: derive from efuse MAC
            String sn = "KC868-A16-" + String((uint32_t)(ESP.getEfuseMac() & 0xFFFFFF), HEX);
            sn.toUpperCase();
            while (sn.length() < 16) sn += " ";
            sn = sn.substring(0, 16);
            return readStringReg(sn, HR_SERIAL_BASE, a);
        }
        if (a >= HR_MANUFACTURER_BASE && a < HR_MANUFACTURER_BASE + 12) {
            String m = "Microcode Engineering"; // requested manufacturer
            while (m.length() < 24) m += " ";
            m = m.substring(0, 24);
            return readStringReg(m, HR_MANUFACTURER_BASE, a);
        }
        if (a >= HR_FW_VER_BASE && a < HR_FW_VER_BASE + 8) {
            String fw = firmwareVersion;
            while (fw.length() < 16) fw += " ";
            fw = fw.substring(0, 16);
            return readStringReg(fw, HR_FW_VER_BASE, a);
        }
        if (a >= HR_HW_VER_BASE && a < HR_HW_VER_BASE + 8) {
            String hw = "KC868-A16";
            while (hw.length() < 16) hw += " ";
            hw = hw.substring(0, 16);
            return readStringReg(hw, HR_HW_VER_BASE, a);
        }
        if (a == HR_YEAR) return 2026;
        if (a == HR_BOARD_MODEL_CODE) return 16;

        // MACs
        if (a >= HR_ETH_MAC_BASE && a < HR_ETH_MAC_BASE + 3) {
            uint8_t b[6] = { 0 };
            (void)parseMacToBytes(ETH.macAddress(), b);
            uint16_t regs3[3];
            macRegsFromBytes(b, regs3);
            return regs3[a - HR_ETH_MAC_BASE];
        }
        if (a >= HR_WIFI_STA_MAC_BASE && a < HR_WIFI_STA_MAC_BASE + 3) {
            uint8_t b[6] = { 0 };
            (void)parseMacToBytes(WiFi.macAddress(), b);
            uint16_t regs3[3];
            macRegsFromBytes(b, regs3);
            return regs3[a - HR_WIFI_STA_MAC_BASE];
        }
        if (a >= HR_WIFI_AP_MAC_BASE && a < HR_WIFI_AP_MAC_BASE + 3) {
            uint8_t b[6] = { 0 };
            (void)parseMacToBytes(WiFi.softAPmacAddress(), b);
            uint16_t regs3[3];
            macRegsFromBytes(b, regs3);
            return regs3[a - HR_WIFI_AP_MAC_BASE];
        }

        // Outputs bitmask (reflect current)
        if (a == HR_OUTPUTS_BITMASK) {
            uint16_t m = 0;
            for (int i = 0; i < 16; i++) if (outputStates[i]) m |= (1 << i);
            return m;
        }

        // RTC set values should reflect current shadow (configured)

        if (a < HR_MAX) {
            return hrShadow[a];
        }

        return 0;
    }

    static uint16_t cbHregSet(TRegister* reg, uint16_t val) {
        uint16_t a = regAddr(reg);

        // RO region - ignore writes
        if (a <= HR_WIFI_AP_MAC_BASE + 2) {
            return cbHregGet(reg, val);
        }

        if (a >= HR_MAX) return 0;

        hrShadow[a] = val;

        // Apply actions
        if (a == HR_HEARTBEAT_WRITE) {
            heartbeatEcho = val;
            heartbeatLastMs = millis();
        }

        if (a == HR_OUTPUTS_BITMASK) {
            setOutputsFromBitmask(val);
        }

        if (a == HR_NET_APPLY && val == APPLY_TOKEN) {
            applyNetworkFromShadow();
            restartRequired = true;
        }

        if (a == HR_MB_APPLY && val == APPLY_TOKEN) {
            applyModbusFromShadow(true);
            initModbus();
        }

        if (a == HR_PROTO_APPLY && val == APPLY_TOKEN) {
            applyUsbFromShadow();
            applyProtocolFromShadow();
            saveCommunicationConfig();
            restartRequired = true;
        }

        if (a == HR_MB_BAUD_HI || a == HR_MB_BAUD_LO || a == HR_MB_DATABITS || a == HR_MB_PARITY ||
            a == HR_MB_STOPBITS || a == HR_MB_SLAVE_ID || a == HR_MB_TIMEOUT_MS || a == HR_MB_RETRY_COUNT) {
            // just stored; apply occurs via MB apply (or user changes each field)
        }

        if (a == HR_OUTPUTS_APPLY && val == APPLY_TOKEN) {
            // outputs already applied from bitmask/coil; keep for compatibility
            writeOutputs();
            broadcastUpdate();
        }

        if (a == HR_RTC_APPLY && val == APPLY_TOKEN) {
            syncTimeFromClient(
                (int)hrShadow[HR_RTC_SET_YEAR],
                (int)hrShadow[HR_RTC_SET_MONTH],
                (int)hrShadow[HR_RTC_SET_DAY],
                (int)hrShadow[HR_RTC_SET_HOUR],
                (int)hrShadow[HR_RTC_SET_MIN],
                (int)hrShadow[HR_RTC_SET_SEC]
            );
        }

        if (a == HR_SYS_REBOOT && val == RESTART_TOKEN) {
            restartRequired = true;
        }

        if (a == HR_SYS_FACTORY_RESET && val == FACTORY_TOKEN) {
            factoryReset();
        }

        return hrShadow[a];
    }

    // Coils
    static uint16_t cbCoilGet(TRegister* reg, uint16_t) {
        uint16_t a = regAddr(reg);

        if (a < 16) return outputStates[a] ? 1 : 0;

        // Command coils always read 0
        if (a == 16 || a == 17) return 0;

        return 0;
    }

    static uint16_t cbCoilSet(TRegister* reg, uint16_t val) {
        uint16_t a = regAddr(reg);

        if (a < 16) {
            bool newState = (val != 0);
            if (outputStates[a] != newState) {
                outputStates[a] = newState;
                writeOutputs();
                broadcastUpdate();
                changeCounter++;
            }
            return newState ? 1 : 0;
        }

        // Command coils
        if (a == 16 && val != 0) {
            doAllOutputs(false);
            return 0;
        }
        if (a == 17 && val != 0) {
            doAllOutputs(true);
            return 0;
        }

        return 0;
    }

    // Discrete inputs
    static uint16_t cbIstsGet(TRegister* reg, uint16_t) {
        uint16_t a = regAddr(reg);
        if (a < 16) return inputStates[a] ? 1 : 0;
        return 0;
    }

    // Input registers
    static uint16_t cbIregGet(TRegister* reg, uint16_t) {
        uint16_t a = regAddr(reg);

        if (a == IR_STATUS_FLAGS) return statusFlags();

        if (a == IR_UPTIME_HI || a == IR_UPTIME_LO) {
            uint32_t up = millis() / 1000;
            return (a == IR_UPTIME_HI) ? u32Hi(up) : u32Lo(up);
        }

        if (a == IR_LAST_ERROR_CODE) {
            // Simple mapping: 0 = OK, 1 = some lastErrorMessage exists
            return (lastErrorMessage.length() > 0) ? 1 : 0;
        }

        if (a == IR_CHANGE_COUNTER) {
            return (uint16_t)(changeCounter & 0xFFFF);
        }

        if (a == IR_HEARTBEAT_ECHO) {
            return heartbeatEcho;
        }

        if (a == IR_HEARTBEAT_AGE_MS) {
            uint32_t age = (heartbeatLastMs == 0) ? 0xFFFFFFFFUL : (millis() - heartbeatLastMs);
            if (age > 0xFFFF) age = 0xFFFF;
            return (uint16_t)age;
        }

        if (a == IR_DI_BITMASK) {
            uint16_t m = 0;
            for (int i = 0; i < 16; i++) if (inputStates[i]) m |= (1 << i);
            return m;
        }

        if (a == IR_DO_BITMASK) {
            uint16_t m = 0;
            for (int i = 0; i < 16; i++) if (outputStates[i]) m |= (1 << i);
            return m;
        }

        // Analog
        if (a == IR_AI1_RAW) return (uint16_t)analogValues[0];
        if (a == IR_AI1_MV)  return analogMv(analogVoltages[0]);
        if (a == IR_AI2_RAW) return (uint16_t)analogValues[1];
        if (a == IR_AI2_MV)  return analogMv(analogVoltages[1]);
        if (a == IR_AI3_RAW) return (uint16_t)analogValues[2];
        if (a == IR_AI3_MV)  return analogMv(analogVoltages[2]);
        if (a == IR_AI4_RAW) return (uint16_t)analogValues[3];
        if (a == IR_AI4_MV)  return analogMv(analogVoltages[3]);

        // Sensors
        if (a == IR_DHT1_TEMP_X10) return (uint16_t)(int16_t)(htSensorConfig[0].configured ? toX10Signed(htSensorConfig[0].temperature) : (int16_t)0x8000);
        if (a == IR_DHT1_HUM_X10)  return (uint16_t)(int16_t)(htSensorConfig[0].configured ? toX10Signed(htSensorConfig[0].humidity) : (int16_t)0x8000);
        if (a == IR_DHT2_TEMP_X10) return (uint16_t)(int16_t)(htSensorConfig[1].configured ? toX10Signed(htSensorConfig[1].temperature) : (int16_t)0x8000);
        if (a == IR_DHT2_HUM_X10)  return (uint16_t)(int16_t)(htSensorConfig[1].configured ? toX10Signed(htSensorConfig[1].humidity) : (int16_t)0x8000);
        if (a == IR_DS18_TEMP_X10) return (uint16_t)(int16_t)(htSensorConfig[2].configured ? toX10Signed(htSensorConfig[2].temperature) : (int16_t)0x8000);

        // RTC
        if (a >= IR_RTC_YEAR && a <= IR_RTC_EPOCH_LO) {
            if (!rtcInitialized) return 0;
            DateTime now = rtc.now();
            switch (a) {
            case IR_RTC_YEAR: return (uint16_t)now.year();
            case IR_RTC_MONTH: return (uint16_t)now.month();
            case IR_RTC_DAY: return (uint16_t)now.day();
            case IR_RTC_HOUR: return (uint16_t)now.hour();
            case IR_RTC_MIN: return (uint16_t)now.minute();
            case IR_RTC_SEC: return (uint16_t)now.second();
            case IR_RTC_DOW: return (uint16_t)now.dayOfTheWeek();
            case IR_RTC_EPOCH_HI: return u32Hi((uint32_t)now.unixtime());
            case IR_RTC_EPOCH_LO: return u32Lo((uint32_t)now.unixtime());
            }
        }

        // Current network snapshot
        if (a == IR_NET_FLAGS) return netFlags();
        if (a == IR_NET_CUR_TCP_PORT) return 80;

        IPAddress curIp(0, 0, 0, 0), curSub(0, 0, 0, 0), curGw(0, 0, 0, 0), curDns1(0, 0, 0, 0), curDns2(0, 0, 0, 0);
        if (ethConnected) {
            curIp = ETH.localIP();
            curSub = ETH.subnetMask();
            curGw = ETH.gatewayIP();
            curDns1 = ETH.dnsIP(0);
            curDns2 = ETH.dnsIP(1);
        }
        else if (wifiClientMode && wifiConnected) {
            curIp = WiFi.localIP();
            curSub = WiFi.subnetMask();
            curGw = WiFi.gatewayIP();
            curDns1 = WiFi.dnsIP(0);
            curDns2 = WiFi.dnsIP(1);
        }
        else if (apMode) {
            curIp = WiFi.softAPIP();
            curSub = subnet;
            curGw = gateway;
            curDns1 = dns1;
            curDns2 = dns2;
        }

        if (a >= IR_NET_CUR_IP_BASE && a <= IR_NET_CUR_IP_BASE + 1) {
            return ipWord(curIp, (uint8_t)(a - IR_NET_CUR_IP_BASE));
        }
        if (a >= IR_NET_CUR_SUB_BASE && a <= IR_NET_CUR_SUB_BASE + 1) {
            return ipWord(curSub, (uint8_t)(a - IR_NET_CUR_SUB_BASE));
        }
        if (a >= IR_NET_CUR_GW_BASE && a <= IR_NET_CUR_GW_BASE + 1) {
            return ipWord(curGw, (uint8_t)(a - IR_NET_CUR_GW_BASE));
        }
        if (a >= IR_NET_CUR_DNS1_BASE && a <= IR_NET_CUR_DNS1_BASE + 1) {
            return ipWord(curDns1, (uint8_t)(a - IR_NET_CUR_DNS1_BASE));
        }
        if (a >= IR_NET_CUR_DNS2_BASE && a <= IR_NET_CUR_DNS2_BASE + 1) {
            return ipWord(curDns2, (uint8_t)(a - IR_NET_CUR_DNS2_BASE));
        }

        if (a == IR_WIFI_RSSI_DBM) {
            int16_t rssi = -127;
            if (wifiClientMode && wifiConnected) rssi = (int16_t)WiFi.RSSI();
            return (uint16_t)rssi;
        }

        if (a == IR_ETH_LINK_SPEED) {
            return ethConnected ? (uint16_t)ETH.linkSpeed() : 0;
        }

        if (a == IR_ETH_DUPLEX) {
            return ethConnected ? (uint16_t)(ETH.fullDuplex() ? 1 : 0) : 0;
        }

        return 0;
    }

} // namespace

bool modbusIsEnabled() {
    return enabled;
}

void initModbus() {
    enabled = false;

    // Only run if RS485 protocol is Modbus RTU (case-insensitive, tolerate minor formatting)
    String proto = rs485Protocol;
    proto.trim();
    proto.toLowerCase();
    proto.replace("_", " ");
    proto.replace("-", " ");
    proto.replace("  ", " ");
    bool isModbusRtu = (proto == "modbus rtu" || proto == "modbusrtu");
    if (!isModbusRtu) {
        debugPrintln("Modbus disabled: rs485Protocol is '" + rs485Protocol + "'");
        return;
    }

    // Refresh shadow
    syncShadowFromGlobals();

    mb.begin(&rs485);
    mb.server((uint8_t)rs485DeviceAddress);

    // Allocate blocks
    mb.addHreg(0, 0, HR_MAX);
    mb.addIreg(0, 0, IR_MAX);
    mb.addCoil(0, false, COIL_MAX);
    mb.addIsts(0, false, ISTS_MAX);

    // Register callbacks
    mb.onGetHreg(0, cbHregGet, HR_MAX);
    mb.onSetHreg(0, cbHregSet, HR_MAX);

    mb.onGetIreg(0, cbIregGet, IR_MAX);

    mb.onGetCoil(0, cbCoilGet, COIL_MAX);
    mb.onSetCoil(0, cbCoilSet, COIL_MAX);

    mb.onGetIsts(0, cbIstsGet, ISTS_MAX);

    enabled = true;
    debugPrintln("Modbus RTU enabled (Slave ID=" + String(rs485DeviceAddress) + ")");
}

void modbusTask() {
    if (!enabled) return;

    mb.task();

    // Restart if requested
    if (restartRequired) {
        delay(250);
        ESP.restart();
    }
}
